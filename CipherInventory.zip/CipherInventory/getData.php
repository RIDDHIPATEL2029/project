<?php
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from the user table
$sql = "SELECT * FROM user";
$result = $conn->query($sql);

$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = [$row["user_id"], $row["username"], $row["password"], $row["email"], $row["role"]];
    }
}

// Close database connection
$conn->close();

echo json_encode($data);
?>
