<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit User
        </div>
        <div class="form-container">
            <?php
              $servername = "localhost";
              $username = "cybersur_new";
              $password = "2fXj!ii8z0aZ";
              $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if userId is set and is a number
                if (isset($_GET["userId"]) && is_numeric($_GET["userId"])) {
                    $userId = $_GET["userId"];

                    // Fetch user details from the database
                    $sql = "SELECT * FROM user WHERE user_id = $userId";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="user_id" value="<?php echo $userId; ?>">
                <div class="form-group">
                    <label for="username" class="form-label">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?php echo $row['username']; ?>">
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?php echo $row['password']; ?>">
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">
                </div>
                <div class="form-group">
                    <label for="role" class="form-label">Role:</label>
                    <input type="text" class="form-control" id="role" name="role" value="<?php echo $row['role']; ?>">
                </div>
                <div class="button-container">
                <button type="submit" class="button-23">Update</button>
                </div>

                </form>


                        <?php
                    } else {
                        echo "User not found";
                    }
                } else {
                    echo "Invalid userId";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the user
                // Retrieve updated user details from the form
                $userId = $_POST["user_id"];
                $username = $_POST["username"];
                $password = $_POST["password"];
                $email = $_POST["email"];
                $role = $_POST["role"];

                // Update the user in the database
                $sql = "UPDATE user SET username='$username', password='$password', email='$email', role='$role' WHERE user_id='$userId'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>User updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='userview.php' class='button-23'>Go to User View</a></div>";
                } else {
                    echo "Error updating user: " . $conn->error;
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
