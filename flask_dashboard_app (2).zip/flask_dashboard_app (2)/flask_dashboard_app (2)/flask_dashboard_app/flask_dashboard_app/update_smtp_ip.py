import os
import socket
from pathlib import Path

env_path = Path(".env")

# Load existing env lines
if env_path.exists():
    with open(env_path, "r") as f:
        lines = f.readlines()
else:
    print("❌ No .env file found.")
    exit(1)

# Extract current SMTP_HOST value
smtp_host = None
for line in lines:
    if line.strip().startswith("SMTP_HOST="):
        smtp_host = line.strip().split("=", 1)[1]
        break

if not smtp_host:
    print("❌ SMTP_HOST not found in .env.")
    exit(1)

# Remove protocol if present
for prefix in ("http://", "https://", "smtp://"):
    if smtp_host.startswith(prefix):
        smtp_host = smtp_host[len(prefix):]

# Remove port if present
smtp_host = smtp_host.split(":")[0]

# Get IP address
try:
    ip_address = socket.gethostbyname(smtp_host)
except socket.gaierror as e:
    print(f"❌ Failed to resolve {smtp_host}: {e}")
    exit(1)

print(f"✅ Resolved {smtp_host} -> {ip_address}")

# Update .env content
new_lines = []
for line in lines:
    if line.strip().startswith("SMTP_HOST="):
        new_lines.append(f"SMTP_HOST={ip_address}\n")
    else:
        new_lines.append(line)

# Save updated .env
with open(env_path, "w") as f:
    f.writelines(new_lines)

print(f"✅ Updated .env with IP: {ip_address}")
print("ℹ Restart your worker to apply changes.")
