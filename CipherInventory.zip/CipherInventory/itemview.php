<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/gridjs/dist/theme/mermaid.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #0b0b0b;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 20px;
        }

        .heading {
            font-size: 30px;
            color: #ffffff;
        }

        .button-container {
            margin-top: 20px;
        }

        /* Button Styling */
        .button-23 {
            background-color: #f0f0f0; /* Light gray background color */
            border: 1px solid #222222;
            border-radius: 8px;
            color: #222222; /* Dark text color */
            font-size: 16px;
            font-weight: 600;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .button-23:hover {
            background-color: #e0e0e0; /* Lighter gray on hover */
        }

        /* Table Styling */
        .gridjs-container {
            border-radius: 8px;
            overflow: hidden;
        }

        .gridjs {
            border-collapse: collapse;
            width: 100%;
        }

        .gridjs th,
        .gridjs td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            color: #0b0b0b;
        }

        .gridjs th {
            background-color: #f0f0f0; /* Light gray background color */
            font-weight: 600;
            text-align: left;
        }

        .gridjs tbody tr:nth-child(even) {
            background-color: #333333;
        }

        .gridjs tbody tr:hover {
            background-color: #444444;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 py-5">
                <div class="row">
                    <div class="col-auto fw-medium heading">
                        Item 
                    </div>
                </div>
                <div class="row mt-3">
                    <div id="wrapper"></div>
                </div>
                <div class="row mt-3 button-container">
                    <div class="col-auto">
                        <a href="item.php" class="button-23" role="button">Add Item</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/gridjs/dist/gridjs.umd.js"></script>
    <script>
        let data = [
            <?php
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            else{
                echo "connected";
            }
            $sql = "SELECT * FROM item";
            $result = $conn->query($sql);
            echo $result->num_rows;
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '["' . $row["Item_id"] . '", "' . $row["category_id"] . '", "' . $row["Item_name"] . '", "' . $row["price"] . '", "' . $row["quantity_available"] . '", "' . $row["description"] . '"],';
                }
            }
            $conn->close();
            ?>
        ];

        let grid = new gridjs.Grid({
            columns: [
                { name: "Item Id", id: "Item_id" },
                { name: "Category Id", id: "category_id" },
                { name: "Item Name", id: "Item_name" },
                { name: "Price ", id: "price" },
                { name: "Quantity Available", id: "quantity_available" },
                { name: "Description ", id: "description" },


                {
                    name: "Actions",
                    formatter: (_, row) => gridjs.html(`<button onclick="editUser('${row.cells[0].data}')" class="btn btn-primary btn-sm">Edit</button>
                                                          <button onclick="deleteUser('${row.cells[0].data}')" class="btn btn-danger btn-sm">Delete</button>`)
                }
            ],
            search: true,
            sort: true,
            resizable: true,
            pagination: true,
            data: data,
        }).render(document.getElementById("wrapper"));

        function editUser(itemId) {
        window.location.href = 'edititem.php?Item_id=' + itemId;
        }

        function deleteUser(itemId) {
            if (confirm("Are you sure you want to delete this Item?")) {
                window.location.href = 'deleteitem.php?Item_id=' + itemId;
            }
        }

    </script>
</body>

</html>
