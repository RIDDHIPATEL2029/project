<?php
    if ($_SERVER["REQUEST_METHOD"] == "GET") {
        $Item_id = $_GET['Item_id'];
        $user_id = $_GET['user_id'];
        $order_id = $_GET['order_id'];
        $quantity = $_GET['quantity'];

        //$url = "http://192.168.166.179/CipherInventory/qrscan.php?Item_id=$Item_id&user_id=$user_id&order_id=$order_id&quantity=$quantity";


        $servername = "localhost";
        $username = "cybersur_new";
        $password = "2fXj!ii8z0aZ";
        $dbname = "cybersur_new";
        
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

       
        
        $sql = "SELECT isqrscanned FROM customer_order WHERE Item_id = $Item_id and order_id=$order_id";
     
        $result=$conn->query($sql);

        if ($result->num_rows > 0) {

            $row = $result->fetch_assoc();
            $isqr=$row["isqrscanned"];
            
         
            if($isqr==1){
                          echo "Already scanned";
            }
            else{
                 

                $sql1="UPDATE item SET quantity_available=quantity_available-".$quantity." WHERE Item_id=".$Item_id;
                $conn->query($sql1);
                
                $sql2="UPDATE customer_order SET isqrscanned=1 WHERE Item_id=".$Item_id." AND order_id=".$order_id;
                $conn->query($sql2);
                echo "please check item view to see balance in admin panel--";
                

        }
    

        }

        else{
            echo "Item Not Found.";
        }
        $conn->close();
        
    
    
}
    ?>

    