<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit Category
        </div>
        <div class="form-container">
            <?php
     $servername = "localhost";
     $username = "cybersur_new";
     $password = "2fXj!ii8z0aZ";
     $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                if (isset($_GET["categoryId"]) && is_numeric($_GET["categoryId"])) {
                    $categoryId = $_GET["categoryId"];

                    // Fetch category details from the database
                    $sql = "SELECT * FROM item_category WHERE category_id = $categoryId";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="category_id" value="<?php echo $categoryId; ?>">
                <div class="form-group">
                    <label for="category_name" class="form-label">Category Name:</label>
                    <input type="text" class="form-control" id="category_name" name="category_name" value="<?php echo $row['category_name']; ?>">
                </div>
                <div class="button-container">
                <button type="submit" class="button-23">Update</button>
                </div>

                </form>


                        <?php
                    } else {
                        echo "Category not found";
                    }
                } else {
                    echo "Invalid categoryId";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the category
                // Retrieve updated category details from the form
                $categoryId = $_POST["category_id"];
                $categoryName = $_POST["category_name"];

                // Update the category in the database
                $sql = "UPDATE item_category SET category_name='$categoryName' WHERE category_id='$categoryId'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>Category updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='itemcategoryview.php' class='button-23'>Go to Other Page</a></div>";
                } else {
                    echo "Error updating category: " . $conn->error;
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
