from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from models import Submission

teacher_routes = Blueprint("teacher_routes", __name__)


@teacher_routes.route("/teacher/submissions")
def all_submissions():
    """
    Teacher Dashboard
    -----------------
    Shows all student submissions:
        - student name
        - AI marks + pass/fail
        - teacher override if exists
    """
    submissions = Submission.query.order_by(Submission.submitted_at.desc()).all()
    return render_template("teacher_dashboard.html", submissions=submissions)


@teacher_routes.route("/teacher/review/<int:submission_id>", methods=["GET", "POST"])
def review_submission(submission_id):
    """
    Teacher Review Page
    -------------------
    Allows a teacher to override:
        - marks
        - pass/fail
        - feedback
    """

    submission = Submission.query.get_or_404(submission_id)

    if request.method == "POST":
        teacher_marks = request.form.get("teacher_marks")
        teacher_feedback = request.form.get("teacher_feedback")
        teacher_pass_fail = request.form.get("teacher_pass_fail")

        # Validation
        if teacher_marks:
            try:
                teacher_marks = int(teacher_marks)
            except ValueError:
                flash("Marks must be a valid number.", "danger")
                return redirect(url_for("teacher_routes.review_submission", submission_id=submission.id))

        # Save override
        submission.teacher_marks = teacher_marks
        submission.teacher_feedback = teacher_feedback
        submission.teacher_final_pass_fail = teacher_pass_fail

        db.session.commit()

        flash("Teacher override saved successfully!", "success")
        return redirect(url_for("teacher_routes.all_submissions"))

    return render_template("review_submission.html", submission=submission)
