import os
import subprocess
import time
import signal

PORT = "1025"

def free_port():
    result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True)
    pid = None
    for line in result.stdout.splitlines():
        if f":{PORT}" in line and "LISTENING" in line:
            pid = line.split()[-1]
            break
    if pid:
        print(f"Killing process {pid} using port {PORT}...")
        subprocess.run(["taskkill", "/PID", pid, "/F"])
    else:
        print(f"No process found using port {PORT}")

def start_smtp():
    print(f"Starting SMTP server on port {PORT} in background...")
    process = subprocess.Popen(
        ["python", "-m", "aiosmtpd", "-n", "-l", f"127.0.0.1:{PORT}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.STDOUT
    )
    return process

if __name__ == "__main__":
    free_port()
    smtp_process = start_smtp()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping SMTP server...")
        smtp_process.send_signal(signal.SIGTERM)
        smtp_process.wait()
