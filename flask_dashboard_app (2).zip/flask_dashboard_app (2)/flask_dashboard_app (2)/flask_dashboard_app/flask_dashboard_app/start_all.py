import subprocess
import os
import time
import signal

PORT = "1025"

# Load .env
from dotenv import load_dotenv
dotenv_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(dotenv_path)

def free_port():
    """Kill any process using the port."""
    result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True)
    pid = None
    for line in result.stdout.splitlines():
        if f":{PORT}" in line and "LISTENING" in line:
            pid = line.split()[-1]
            break
    if pid:
        print(f"Killing process {pid} using port {PORT}...")
        subprocess.run(["taskkill", "/PID", pid, "/F"])
    else:
        print(f"No process found using port {PORT}")

def start_smtp():
    """Start local SMTP server."""
    print(f"Starting SMTP server on 127.0.0.1:{PORT} ...")
    process = subprocess.Popen(
        ["python", "-m", "aiosmtpd", "-n", "-l", f"127.0.0.1:{PORT}"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL
    )
    return process

def start_worker():
    """Start email worker."""
    print("Starting email worker...")
    process = subprocess.Popen(
        ["python", "-m", "cocomaro.email_worker", "--poll"]
    )
    return process

if __name__ == "__main__":
    free_port()
    smtp_process = start_smtp()
    time.sleep(2)  # give SMTP server time to start
    worker_process = start_worker()

    try:
        # Keep script running
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping all processes...")
        worker_process.terminate()
        smtp_process.terminate()
        worker_process.wait()
        smtp_process.wait()
        print("All processes stopped.")
