import serial
import time
import re

# ----------------------- #
#      CONFIGURATION      #
# ----------------------- #

S99_PORT = "COM4"          # COM port of S-99 RS232 -> USB adapter
ARDUINO_PORT = "COM5"      # COM port of Arduino UNO
BAUD_RATE_S99 = 9600       # Check S-99 manual
BAUD_RATE_ARDUINO = 9600
WEIGHT_THRESHOLD = 500.0   # Target weight in grams


# ----------------------- #
#   SERIAL CONNECTIONS    #
# ----------------------- #

try:
    s99_serial = serial.Serial(S99_PORT, BAUD_RATE_S99, timeout=1)
    arduino_serial = serial.Serial(ARDUINO_PORT, BAUD_RATE_ARDUINO, timeout=1)
    time.sleep(2)

    print(f"✅ Connected to S-99 on {S99_PORT}")
    print(f"✅ Connected to Arduino on {ARDUINO_PORT}\n")

except Exception as e:
    print("❌ Connection error:", e)
    exit()


# ----------------------- #
#    HELPER FUNCTIONS     #
# ----------------------- #

def send_command(cmd):
    """Send control command to Arduino."""
    arduino_serial.write((cmd + "\n").encode())
    print(f"> Sent to Arduino: {cmd}")


def read_arduino_response():
    """Read and print responses from Arduino."""
    while arduino_serial.in_waiting > 0:
        msg = arduino_serial.readline().decode(errors='ignore').strip()
        if msg:
            print("Arduino:", msg)


def read_weight_from_s99():
    """
    Read one line from S-99 RS232 output,
    extract numeric value,
    detect unit (g/kg),
    return weight in grams.
    """
    try:
        line = s99_serial.readline().decode(errors='ignore').strip()
        if line:
            match = re.search(r"([-+]?\d*\.\d+|\d+)", line)
            if match:
                weight = float(match.group(0))

                # Detect unit
                if "kg" in line.lower():
                    weight *= 1000
                elif "g" in line.lower():
                    pass  # already grams
                else:
                    pass  # assume grams

                return weight
    except Exception:
        pass

    return None


# ----------------------- #
#    MAIN CONTROL LOOP    #
# ----------------------- #

try:
    print("✅ System Active — Monitoring weight from S-99...\n")

    conveyor_running = False

    while True:
        weight = read_weight_from_s99()

        if weight is not None:
            print(f"Detected Weight: {weight:.1f} g")

            # ---- STOP & PICK ----
            if weight >= WEIGHT_THRESHOLD and conveyor_running:
                send_command("STOP")
                read_arduino_response()
                time.sleep(1)

                send_command("PICK")
                read_arduino_response()

                conveyor_running = False

            # ---- RESET & RUN ----
            elif weight <= 1 and not conveyor_running:
                send_command("RESET")
                read_arduino_response()
                time.sleep(1)

                send_command("RUN")
                read_arduino_response()

                conveyor_running = True

        time.sleep(0.2)

except KeyboardInterrupt:
    print("\n🛑 Manual stop detected. Halting system.")
    send_command("STOP")
    s99_serial.close()
    arduino_serial.close()
