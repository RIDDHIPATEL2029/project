from flask import Blueprint, render_template, request, redirect, url_for, flash
from app import db
from models import Submission
from ai_module import evaluate_assignment

student_bp = Blueprint('student', __name__)


# ---------------------------
# Student: Submit assignment
# ---------------------------
@student_bp.route('/')
def home():
    return render_template('submit.html', title="Submit Assignment")


@student_bp.route('/submit', methods=['POST'])
def submit_assignment():
    try:
        student_name = request.form.get("student_name")
        content = request.form.get("content")

        # Call AI module to grade
        ai_result = evaluate_assignment(content)

        # Save in database
        submission = Submission(
            student_name=student_name,
            content=content,
            ai_marks=ai_result["marks"],
            ai_feedback=ai_result["feedback"],
            ai_pass_fail=ai_result["pass_fail"]
        )

        db.session.add(submission)
        db.session.commit()

        flash("Assignment submitted successfully!", "success")

        return redirect(url_for('student.view_result', submission_id=submission.id))

    except Exception as e:
        flash(f"Error: {str(e)}", "danger")
        return redirect(url_for('student.home'))


# ---------------------------
# Student: View AI Result
# ---------------------------
@student_bp.route('/result/<int:submission_id>')
def view_result(submission_id):
    submission = Submission.query.get_or_404(submission_id)
    return render_template("result.html", submission=submission, title="AI Result")
