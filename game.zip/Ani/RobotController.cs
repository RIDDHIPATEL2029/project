using System.Collections;
using System.Collections.Specialized;
using System.Security.Cryptography;
using UnityEngine;

public class RobotController : MonoBehaviour
{
    // Wheel Colliders for controlling wheel physics
    [SerializeField] private WheelCollider FLC; // F-Front Left Wheel Collider
    [SerializeField] private WheelCollider FRC; // F-Front Right Wheel Collider
    [SerializeField] private WheelCollider RLC; // R-Rear Left Wheel Collider
    [SerializeField] private WheelCollider RRC; // R-Rear Right Wheel Collider

    // Wheel Transforms for updating wheel visuals
    [SerializeField] private Transform FLT; // F-Front Left Wheel Transform
    [SerializeField] private Transform FRT; // F-Front Right Wheel Transform
    [SerializeField] private Transform RLT; // R- Rear Left Wheel Transform
    [SerializeField] private Transform RRT; // R- Rear Right Wheel Transform

    // Sensors for obstacle detection
    [SerializeField] private Transform FRS; // F-Front Sensor
    [SerializeField] private Transform L1S; // L-Left Sensor 1
    [SerializeField] private Transform L2S; // L-Left Sensor 2
    [SerializeField] private Transform L3S; // L-Left Sensor 3
    [SerializeField] private Transform R1S; // R- Right Sensor 1
    [SerializeField] private Transform R2S; // R- Right Sensor 2
    [SerializeField] private Transform R3S; // R- Right Sensor 3
    [SerializeField] private Transform ORS; // O -Obstacle Right Sensor

    // Configuration parameters
    private float sensorRange = 30f;        // --Range for sensor raycasting
    float value = 50f;                      // --General configurable value
    private float motorTorque = 50f;        // --Torque applied to the wheels
    private float maxSteeringAngle = 30f;   // --Maximum steering angle
    float maxSpeed = 10.5f;                 // --Maximum speed of the robot
    Rigidbody rb;                           // --Rigidbody component for physics
    private int roadLayer;                  // --Layer representing the road
    float downwardAngle = 1.8f;             // --Angle for downward-facing sensors
    float ORSRange = 30f;                   // --Specific range for the ORS sensor

    private void Start()
    {
        // Initialize road layer for collision detection
        roadLayer = LayerMask.NameToLayer("Road");

        // Adjust sensor orientations
        RotateSensorsToFaceForwardAndDown();

        // Cache Rigidbody component for later use
        rb = GetComponent<Rigidbody>();

        // Schedule periodic braking
        Invoke("ApplyBrake", 50f);
    }

    void ApplyBrake()
    {
        // Apply braking force to all wheels
        FLC.brakeTorque = 1000;
        FRC.brakeTorque = 1000;
        RLC.brakeTorque = 1000;
        RRC.brakeTorque = 1000;

        // Schedule brake release after a short delay
        Invoke("ReleaseBrake", 0.5f);

        // Schedule the next brake application
        Invoke("ApplyBrake", 50f);
    }

    void ReleaseBrake()
    {
        // Release braking force from all wheels
        FLC.brakeTorque = 0;
        FRC.brakeTorque = 0;
        RLC.brakeTorque = 0;
        RRC.brakeTorque = 0;
    }

    private void RotateSensorsToFaceForwardAndDown()
    {
        float downAngle = 4f;
        // Front Sensor (FRS) facing forward and slightly downward
        FRS.localRotation = Quaternion.Euler(downAngle, 0, 0);

        // Left Sensors (L1S, L2S, L3S) facing left and slightly downward
        L1S.localRotation = Quaternion.Euler(downAngle, - 5, 0);
        L2S.localRotation = Quaternion.Euler(downAngle, - 10, 0);
        L3S.localRotation = Quaternion.Euler(downAngle, - 15, 0);

        // Right Sensors (R1S, R2S, R3S) facing right and slightly downward
        R1S.localRotation = Quaternion.Euler(downAngle, 5, 0);
        R2S.localRotation = Quaternion.Euler(downAngle, 10, 0);
        R3S.localRotation = Quaternion.Euler(downAngle, 15, 0);

        // Obstacle Right Sensor (ORS) facing right and slightly downward
        ORS.rotation = Quaternion.Euler(downAngle, 180, 0);
    }

    private void FixedUpdate()
    {
        // Use sensors to detect obstacles and make steering decisions
        HandleSteeringAndObstacleAvoidance();

        // Update wheel visuals to match the colliders
        UpdateWheel(FLC, FLT);
        UpdateWheel(FRC, FRT);
        UpdateWheel(RLC, RLT);
        UpdateWheel(RRC, RRT);
    }

    private void MoveForward()
    {
        // Apply motor torque to drive the vehicle forward
        if (rb.velocity.magnitude < maxSpeed)
        {
            FLC.motorTorque = motorTorque;
            FRC.motorTorque = motorTorque;
            RLC.motorTorque = motorTorque;
            RRC.motorTorque = motorTorque;
        }
        else
        {
            Reverse();
        }
        if(rb.velocity.z>0 && FLC.motorTorque > 0)
        {
            float nitro = 800;
            FLC.motorTorque = nitro;
            FRC.motorTorque = nitro;
            RLC.motorTorque = nitro;
            RRC.motorTorque = nitro;
        }
    }

    private void HandleSteeringAndObstacleAvoidance()
    {
        if(IsFrontClear())
        {
            if (!IsLeftClear())
            {
                SteerRight();
            }
            if (!IsRightClear())
            {
                SteerLeft();
            }
            if(IsLeftClear() && IsRightClear())
            {
                ContinueStraight();
            }
            MoveForward();
        }
        else
        {
            if(IsLeftRoad() && !IsObstacleOnLeft())
            {
                SteerLeft();
            }
            else if (IsRightRoad() && !IsObstacleOnRight())
            {
                SteerRight();
            }
            else
            {
                if((Widerightcheck(R1S) || Widerightcheck(R2S) || Widerightcheck(R3S)) && !(Wideleftcheck(L1S) && Wideleftcheck(L2S) && Wideleftcheck(L3S)))
                {
                    SteerRight();
                    motorTorque = 1200f;
                }
                else if (!(Widerightcheck(R1S) && Widerightcheck(R2S) && Widerightcheck(R3S)) && (Wideleftcheck(L1S) || Wideleftcheck(L2S) || Wideleftcheck(L3S)))
                {
                    SteerLeft();
                    motorTorque = 1200f;
                }
                else
                {
                    //motorTorque = 10f;
                    //ContinueStraight();
                }
                MoveForward();
                motorTorque = value;
            }
        }
    }
// private bool DetectIfObstacle(Transform sensor)
// {
//     // Cast a ray from the given sensor to detect obstacles within the detection range
//     RaycastHit raycastResult;
//     bool obstacleDetected = Physics.Raycast(sensor.position, sensor.forward, out raycastResult, detectionRange) &&
//                             raycastResult.collider.gameObject.layer == LayerMask.NameToLayer("Obstacle"); // Exclude ground detection

//     // Visualize the ray as green if no obstacle is detected, and red if an obstacle is detected
//     Debug.DrawRay(sensor.position, sensor.forward * detectionRange, obstacleDetected ? Color.red : Color.green);
//     return obstacleDetected;
// }

// private void SyncWheelWithCollider(WheelCollider wheelCollider, Transform wheelTransform)
// {
//     // Retrieve the world position and rotation of the WheelCollider
//     Vector3 position;
//     Quaternion rotation;
//     wheelCollider.GetWorldPose(out position, out rotation);

//     // Apply the position and rotation to the corresponding wheel transform
//     wheelTransform.position = position;
//     wheelTransform.rotation = rotation;
// }

    bool Widerightcheck(Transform sensor)
    {
        //Vector3 leftDirection = ORS.TransformDirection(Quaternion.Euler(downwardAngle, -70, 0) * Vector3.forward);
        Vector3 rightDirection = sensor.TransformDirection(Quaternion.Euler(downwardAngle, 60, 0) * Vector3.forward);
        RaycastHit hit;
        Physics.Raycast(sensor.position, rightDirection, out hit, ORSRange, -1, QueryTriggerInteraction.Ignore);
        if (hit.collider == null)
        {
            return false;
        }
        bool isRoad = hit.collider.gameObject.layer == roadLayer || hit.collider.gameObject.layer == LayerMask.NameToLayer("Obs");
        //Debug.DrawRay(sensor.position, rightDirection * ORSRange, isRoad ? Color.green : Color.red);
        return isRoad;
    }

    bool Wideleftcheck(Transform sensor)
    {
        Vector3 leftDirection = sensor.TransformDirection(Quaternion.Euler(downwardAngle, -60, 0) * Vector3.forward);
        //Vector3 rightDirection = ORS.TransformDirection(Quaternion.Euler(downwardAngle, 70, 0) * Vector3.forward);
        RaycastHit hit;
        Physics.Raycast(sensor.position, leftDirection, out hit, ORSRange, -1, QueryTriggerInteraction.Ignore);
        if (hit.collider == null)
        {
            return false;
        }
        bool isRoad = hit.collider.gameObject.layer == roadLayer || hit.collider.gameObject.layer == LayerMask.NameToLayer("Obs");
        //Debug.DrawRay(sensor.position, leftDirection * ORSRange, isRoad ? Color.green : Color.red);
        return isRoad;
    }

    private void SteerLeft()
    {
        FLC.steerAngle = -maxSteeringAngle;
        FRC.steerAngle = -maxSteeringAngle;
    }

    private void SteerRight()
    {
        FLC.steerAngle = maxSteeringAngle;
        FRC.steerAngle = maxSteeringAngle;
    }

    private void ContinueStraight()
    {
        FLC.steerAngle = 0;
        FRC.steerAngle = 0;
    }

    private void Reverse()
    {
        FLC.motorTorque = -motorTorque ;
        FRC.motorTorque = -motorTorque ;
        RLC.motorTorque = -motorTorque ;
        RRC.motorTorque = -motorTorque ;
    }

    private bool IsFrontClear()
    {
        return IsRoad(FRS);
    }

// private bool IsObstacleDetectedOnLeft()
// {
//     // Check if any of the left-side sensors detect an obstacle
//     return DetectObstacle(LeftSensor1) || DetectObstacle(LeftSensor2) || DetectObstacle(LeftSensor3);
// }

// private bool IsObstacleDetectedOnRight()
// {
//     // Check if any of the right-side sensors or the obstacle sensor detect an obstacle
//     return DetectObstacle(RightSensor1) || DetectObstacle(RightSensor2) || DetectObstacle(RightSensor3) || DetectObstacle(ObstacleSensor);
// }

// private bool DetectObstacle(Transform sensor)
// {
//     // Cast a ray from the sensor to detect obstacles within the specified range
//     RaycastHit hitInfo;
//     bool isObstacleDetected = Physics.Raycast(sensor.position, sensor.forward, out hitInfo, detectionRange) &&
//                               hitInfo.collider.gameObject.layer == LayerMask.NameToLayer("Obstacle"); // Exclude ground detection

//     // Visualize the ray in the scene with red for obstacle and green for clear path
//     Debug.DrawRay(sensor.position, sensor.forward * detectionRange, isObstacleDetected ? Color.red : Color.green);
//     return isObstacleDetected;
// }

    private bool IsRightClear()
    {
        return IsRoad(R1S) && IsRoad(R2S) && IsRoad(R3S);
    }

    private bool IsLeftClear()
    {
        return IsRoad(L1S) && IsRoad(L2S) && IsRoad(L3S);
    }

    bool IsLeftRoad()
    {
        return IsRoad(L1S) || IsRoad(L2S) || IsRoad(L3S);
    }

    private bool IsRightRoad()
    {
        return IsRoad(R1S) || IsRoad(R2S) || IsRoad(R3S);
    }

    bool IsRoad(Transform sensor)
    {
        RaycastHit hit;
        Physics.Raycast(sensor.position, sensor.forward, out hit, sensorRange,-1,QueryTriggerInteraction.Ignore);
        if (hit.collider == null)
        {
            return false;
        }
        bool isRoad = hit.collider.gameObject.layer == roadLayer;//|| hit.collider.gameObject.layer == LayerMask.NameToLayer("Default");
        //Debug.DrawRay(sensor.position, sensor.forward * sensorRange, isRoad ? Color.green : Color.red);
        return isRoad;
    }

    private bool IsObstacleOnLeft()
    {
        return CheckObstacle(L1S) || CheckObstacle(L2S) || CheckObstacle(L3S);
    }
// private bool HasObstacleOnRight()
// {
//     // Check for obstacles on the right side using the specified sensors
//     return DetectObstacle(R1S) || DetectObstacle(R2S) || DetectObstacle(R3S) || DetectObstacle(ORS);
// }

// private bool DetectObstacle(Transform sensor)
// {
//     RaycastHit hitInfo;

//     // Perform a raycast from the sensor's position in its forward direction
//     // and check if it hits an object in the "Obs" layer within the sensor range
//     bool obstacleDetected = Physics.Raycast(sensor.position, sensor.forward, out hitInfo, sensorRange) &&
//                             hitInfo.collider.gameObject.layer == LayerMask.NameToLayer("Obs");

//     // Uncomment the following line to visualize the raycast in the Scene view
//     // Debug.DrawRay(sensor.position, sensor.forward * sensorRange, obstacleDetected ? Color.red : Color.green);

//     return obstacleDetected;
// }

// private void SyncWheelPositionAndRotation(WheelCollider wheelCollider, Transform wheelTransform)
// {
//     Vector3 position;
//     Quaternion rotation;

//     // Retrieve the current world position and rotation of the wheel collider
//     wheelCollider.GetWorldPose(out position, out rotation);

//     // Apply the retrieved position and rotation to the wheel transform for visual updates
//     wheelTransform.position = position;
//     wheelTransform.rotation = rotation;
// }

    private bool IsObstacleOnRight()
    {
        return CheckObstacle(R1S) || CheckObstacle(R2S) || CheckObstacle(R3S) || CheckObstacle(ORS);
    }

    private bool CheckObstacle(Transform sensor)
    {
        RaycastHit hit;
        bool isObstacle = Physics.Raycast(sensor.position, sensor.forward, out hit, sensorRange) &&
                          hit.collider.gameObject.layer == LayerMask.NameToLayer("Obs");

        //Debug.DrawRay(sensor.position, sensor.forward * sensorRange, isObstacle ? Color.red : Color.green);
        return isObstacle;
    }

    private void UpdateWheel(WheelCollider collider, Transform transform)
    {
        Vector3 pos;
        Quaternion rot;
        collider.GetWorldPose(out pos, out rot);
        transform.position = pos;
        transform.rotation = rot;
    }
}
