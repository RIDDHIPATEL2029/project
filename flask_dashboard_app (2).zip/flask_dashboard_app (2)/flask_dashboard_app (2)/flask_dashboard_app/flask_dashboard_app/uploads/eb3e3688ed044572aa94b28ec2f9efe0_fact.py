nums = input().split()
total = 0
for n in nums:
    try:
        total += int(n)
    except:
        pass
print(total)