<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit Order
        </div>
        <div class="form-container">
            <?php
                $servername = "localhost";
                $username = "cybersur_new";
                $password = "2fXj!ii8z0aZ";
                $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if orderId is set and is a number
                if (isset($_GET["orderId"]) && is_numeric($_GET["orderId"])) {
                    $orderId = $_GET["orderId"];

                    // Fetch order details from the database
                    $sql = "SELECT * FROM customer_order WHERE order_id = $orderId";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="order_id" value="<?php echo $orderId; ?>">
                <div class="form-group">
                    <label for="user_id" class="form-label">User ID:</label>
                    <input type="text" class="form-control" id="user_id" name="user_id" value="<?php echo $row['user_id']; ?>">
                </div>
                <div class="form-group">
                    <label for="order_date" class="form-label">Order Date:</label>
                    <input type="text" class="form-control" id="order_date" name="order_date" value="<?php echo $row['order_date']; ?>">
                </div>
                <div class="form-group">
                    <label for="total_price" class="form-label">Total Price:</label>
                    <input type="text" class="form-control" id="total_price" name="total_price" value="<?php echo $row['total_price']; ?>">
                </div>
                <div class="button-container">
                <button type="submit" class="button-23">Update</button>
                </div>

                </form>


                        <?php
                    } else {
                        echo "Order not found";
                    }
                } else {
                    echo "Invalid orderId";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the order
                // Retrieve updated order details from the form
                $orderId = $_POST["order_id"];
                $userId = $_POST["user_id"];
                $orderDate = $_POST["order_date"];
                $totalPrice = $_POST["total_price"];

                // Update the order in the database
                $sql = "UPDATE customer_order SET user_id='$userId', order_date='$orderDate', total_price='$totalPrice' WHERE order_id='$orderId'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>Order updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='orderview.php' class='button-23'>Go to Other Page</a></div>";
                } else {
                    echo "Error updating order: " . $conn->error;
                }
                
                
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
