<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Supplier</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        .message {
            text-align: center;
            margin-bottom: 20px;
        }

        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
            margin-top: 10px;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="message">
            <?php
            $servername = "localhost";
            $username = "cybersur_new";
            $password = "2fXj!ii8z0aZ";
            $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if supplier_id is set and is a number
                if (isset($_GET["supplierId"]) && is_numeric($_GET["supplierId"])) {
                    $supplierId = $_GET["supplierId"];
            
                    // Delete the supplier from the database
                    $sql = "DELETE FROM supplier WHERE supplier_id=$supplierId";
            
                    if ($conn->query($sql) === TRUE) {
                        echo "Supplier deleted successfully";
                    } else {
                        echo "Error deleting supplier: " . $conn->error;
                    }
                } else {
                    echo "Invalid Supplier ID";
                }
            }
            

            $conn->close();
            ?>
        </div>
        <div class="button-container">
            <a href="supplierview.php" class="button-23">Go to Supplier View</a>
        </div>
    </div>
</body>
</html>
