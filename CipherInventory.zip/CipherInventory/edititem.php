<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit Item
        </div>
        <div class="form-container">
            <?php
            $servername = "localhost";
            $username = "cybersur_new";
            $password = "2fXj!ii8z0aZ";
            $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if Item_id is set and is a number
                if (isset($_GET["Item_id"]) && is_numeric($_GET["Item_id"])) {
                    $itemId = $_GET["Item_id"];

                    // Fetch item details from the database
                    $sql = "SELECT * FROM item WHERE Item_id = $itemId";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="Item_id" value="<?php echo $itemId; ?>">
                <div class="form-group">
                    <label for="category_id" class="form-label">Category ID:</label>
                    <input type="text" class="form-control" id="category_id" name="category_id" value="<?php echo $row['category_id']; ?>">
                </div>
                <div class="form-group">
                    <label for="Item_name" class="form-label">Item Name:</label>
                    <input type="text" class="form-control" id="Item_name" name="Item_name" value="<?php echo $row['Item_name']; ?>">
                </div>
                <div class="form-group">
                    <label for="price" class="form-label">Price:</label>
                    <input type="text" class="form-control" id="price" name="price" value="<?php echo $row['price']; ?>">
                </div>
                <div class="form-group">
                    <label for="quantity_available" class="form-label">Quantity Available:</label>
                    <input type="text" class="form-control" id="quantity_available" name="quantity_available" value="<?php echo $row['quantity_available']; ?>">
                </div>
                <div class="form-group">
                    <label for="description" class="form-label">Description:</label>
                    <input type="text" class="form-control" id="description" name="description" value="<?php echo $row['description']; ?>">
                </div>
                <div class="button-container">
                    <button type="submit" class="button-23">Update</button>
                </div>
                </form>

                        <?php
                    } else {
                        echo "Item not found";
                    }
                } else {
                    echo "Invalid Item ID";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the item
                // Retrieve updated item details from the form
                $itemId = $_POST["Item_id"];
                $categoryId = $_POST["category_id"];
                $itemName = $_POST["Item_name"];
                $price = $_POST["price"];
                $quantityAvailable = $_POST["quantity_available"];
                $description = $_POST["description"];

                // Update the item in the database
                $sql = "UPDATE item SET category_id='$categoryId', Item_name='$itemName', price='$price', quantity_available='$quantityAvailable', description='$description' WHERE Item_id='$itemId'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>Item updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='itemview.php' class='button-23'>Go to Other Page</a></div>";
                } else {
                    echo "Error updating item: " . $conn->error;
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
