import pygame
import math
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
RING_RADIUS = 200
PLAYER_RADIUS = 30
FPS = 60

# Colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Sumo Wrestling Game")
clock = pygame.time.Clock()

# Load images (with fallback to circles if images are missing)
try:
    player_img = pygame.image.load("player.png")
    player_img = pygame.transform.scale(player_img, (PLAYER_RADIUS * 2, PLAYER_RADIUS * 2))
except FileNotFoundError:
    player_img = None
try:
    ai_img = pygame.image.load("ai.png")
    ai_img = pygame.transform.scale(ai_img, (PLAYER_RADIUS * 2, PLAYER_RADIUS * 2))
except FileNotFoundError:
    ai_img = None
try:
    crowd_img = pygame.image.load("crowd.png")
    crowd_img = pygame.transform.scale(crowd_img, (WIDTH, HEIGHT))
except FileNotFoundError:
    crowd_img = None

# Player properties
player1_pos = [WIDTH // 2 - 100, HEIGHT // 2]
player2_pos = [WIDTH // 2 + 100, HEIGHT // 2]
player1_vel = [0, 0]
player2_vel = [0, 0]
player_speed = 0.15  # Slowed down
ai_speed = 0.12      # Slowed down
friction = 0.95      # Increased for less slipperiness

# Game state
game_over = False
winner = None

# Cheering particles
particles = []  # List of [x, y, angle, speed, lifetime]

def setup():
    global player1_pos, player2_pos, player1_vel, player2_vel, game_over, winner, particles
    player1_pos = [WIDTH // 2 - 100, HEIGHT // 2]
    player2_pos = [WIDTH // 2 + 100, HEIGHT // 2]
    player1_vel = [0, 0]
    player2_vel = [0, 0]
    game_over = False
    winner = None
    particles = []

def distance_from_center(pos):
    center = [WIDTH // 2, HEIGHT // 2]
    return math.sqrt((pos[0] - center[0]) ** 2 + (pos[1] - center[1]) ** 2)

def check_collision():
    dx = player1_pos[0] - player2_pos[0]
    dy = player1_pos[1] - player2_pos[1]
    distance = math.sqrt(dx ** 2 + dy ** 2)
    if distance < 2 * PLAYER_RADIUS:
        # Simple collision: transfer some velocity
        player1_vel[0] += dx * 0.05
        player1_vel[1] += dy * 0.05
        player2_vel[0] -= dx * 0.05
        player2_vel[1] -= dy * 0.05
        # Push players apart
        overlap = (2 * PLAYER_RADIUS - distance) / 2
        if distance > 0:
            player1_pos[0] += dx / distance * overlap
            player1_pos[1] += dy / distance * overlap
            player2_pos[0] -= dx / distance * overlap
            player2_pos[1] -= dy / distance * overlap

def spawn_cheering_particles():
    # Spawn particles around the ring
    if random.random() < 0.1:  # 10% chance per frame
        angle = random.uniform(0, 2 * math.pi)
        x = WIDTH // 2 + math.cos(angle) * (RING_RADIUS + 10)
        y = HEIGHT // 2 + math.sin(angle) * (RING_RADIUS + 10)
        particle_angle = angle + math.pi  # Move outward
        speed = random.uniform(1, 3)
        lifetime = random.randint(20, 40)  # Frames
        particles.append([x, y, particle_angle, speed, lifetime])

def update_particles():
    # Update and remove expired particles
    for particle in particles[:]:
        particle[0] += math.cos(particle[2]) * particle[3]
        particle[1] += math.sin(particle[2]) * particle[3]
        particle[4] -= 1
        if particle[4] <= 0:
            particles.remove(particle)

def update_loop():
    global player1_pos, player2_pos, player1_vel, player2_vel, game_over, winner
    
    if game_over:
        # Check for restart
        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:
            setup()
        return

    # Handle Player 1 input (WASD)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        player1_vel[1] -= player_speed
    if keys[pygame.K_s]:
        player1_vel[1] += player_speed
    if keys[pygame.K_a]:
        player1_vel[0] -= player_speed
    if keys[pygame.K_d]:
        player1_vel[0] += player_speed

    # AI for Player 2: chase Player 1
    dx = player1_pos[0] - player2_pos[0]
    dy = player1_pos[1] - player2_pos[1]
    distance = math.sqrt(dx ** 2 + dy ** 2)
    if distance > 0:
        # Normalize direction and apply AI speed
        player2_vel[0] += (dx / distance) * ai_speed
        player2_vel[1] += (dy / distance) * ai_speed

    # Apply friction
    player1_vel[0] *= friction
    player1_vel[1] *= friction
    player2_vel[0] *= friction
    player2_vel[1] *= friction

    # Update positions
    player1_pos[0] += player1_vel[0]
    player1_pos[1] += player1_vel[1]
    player2_pos[0] += player2_vel[0]
    player2_pos[1] += player2_vel[1]

    # Check collision
    check_collision()

    # Check if players are out of the ring
    if distance_from_center(player1_pos) > RING_RADIUS:
        game_over = True
        winner = "AI"
    elif distance_from_center(player2_pos) > RING_RADIUS:
        game_over = True
        winner = "Player"

    # Update cheering particles
    spawn_cheering_particles()
    update_particles()

    # Draw
    screen.fill(BLACK)
    # Draw crowd background (if available)
    if crowd_img:
        screen.blit(crowd_img, (0, 0))
    # Draw players
    if player_img:
        screen.blit(player_img, (int(player1_pos[0] - PLAYER_RADIUS), int(player1_pos[1] - PLAYER_RADIUS)))
    else:
        pygame.draw.circle(screen, RED, (int(player1_pos[0]), int(player1_pos[1])), PLAYER_RADIUS)
    if ai_img:
        screen.blit(ai_img, (int(player2_pos[0] - PLAYER_RADIUS), int(player2_pos[1] - PLAYER_RADIUS)))
    else:
        pygame.draw.circle(screen, BLUE, (int(player2_pos[0]), int(player2_pos[1])), PLAYER_RADIUS)
    # Draw cheering particles
    for particle in particles:
        pygame.draw.circle(screen, WHITE, (int(particle[0]), int(particle[1])), 2)
    # Display winner and restart prompt
    if game_over:
        font_large = pygame.font.Font(None, 74)
        winner_text = font_large.render(f"{winner} Wins!", True, WHITE)
        screen.blit(winner_text, (WIDTH // 2 - winner_text.get_width() // 2, HEIGHT // 2 - winner_text.get_height() // 2))
        font = pygame.font.Font(None, 36)
        restart_text = font.render("Press R to Restart", True, WHITE)
        screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 50))
    
    pygame.display.flip()

def main():
    setup()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        
        update_loop()
        clock.tick(FPS)
    
    pygame.quit()

if __name__ == "__main__":
    main()