# Example test cases for auto-grading Python code assignments
# Each test case is a tuple: (input, expected_output)
test_cases = [
    ("2 3", "5"),
    ("-1 1", "0"),
    ("100 200", "300"),
]


def run_student_code(student_file_path):
    import subprocess
    results = []
    for inp, expected in test_cases:
        try:
            proc = subprocess.run(
                ["python", student_file_path],
                input=inp.encode(),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=2
            )
            output = proc.stdout.decode().strip()
            passed = (output == expected)
            results.append((inp, expected, output, passed))
        except Exception as e:
            results.append((inp, expected, str(e), False))
    return results

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python test_cases.py <student_code.py>")
        sys.exit(1)
    student_file = sys.argv[1]
    results = run_student_code(student_file)
    passed_count = 0
    for idx, (inp, expected, output, passed) in enumerate(results, 1):
        print(f"Test {idx}: Input: {inp} | Expected: {expected} | Output: {output} | {'PASS' if passed else 'FAIL'}")
        if passed:
            passed_count += 1
    total = len(results)
    print(f"MARKS: {int((passed_count/total)*100)}")
