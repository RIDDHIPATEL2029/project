# Cocomaro – Email-Based Personalized Coding Education with AI Auto-Assignment

Cocomaro is a Python/Flask application that delivers personalized coding exercises **via email**, auto-grades replies, gives feedback, and provides an **instructor dashboard** for analytics. It is designed to work under **low-bandwidth** conditions and to be simple to deploy.

## Features
- Student registration by email
- Email delivery of coding exercises
- Students submit code by replying to the email (code in body or as `.py` attachment)
- Secure(ish) auto-grader with time & memory limits
- Personalization engine (ELO-like)
- Instructor dashboard (web)
- SQLite storage for portability

## Quick Start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# Configure email in .env
cp .env.example .env

# Init database and load problems
python -m cocomaro.app --init-db
python -m cocomaro.app --load-sample-problems

# Run dashboard
flask --app cocomaro.app run --debug

# Run email worker
python -m cocomaro.email_worker --poll
