import serial
import time
import re
import sys

# ----------------------- #
#      CONFIGURATION      #
# ----------------------- #

S99_PORT = "COM4"          # COM port of S-99 RS232 -> USB adapter
ARDUINO_PORT = "COM5"      # COM port of Arduino UNO
BAUD_RATE_S99 = 9600       # Check S-99 manual
BAUD_RATE_ARDUINO = 9600
WEIGHT_THRESHOLD = 500.0   # Target weight in grams


# ----------------------- #
#   SERIAL CONNECTIONS    #
# ----------------------- #

def setup_serial_connections():
    try:
        s99 = serial.Serial(S99_PORT, BAUD_RATE_S99, timeout=1)
        arduino = serial.Serial(ARDUINO_PORT, BAUD_RATE_ARDUINO, timeout=1)
        time.sleep(2)

        print(f"✅ Connected to S-99 on {S99_PORT}")
        print(f"✅ Connected to Arduino on {ARDUINO_PORT}\n")
        return s99, arduino
    except Exception as e:
        print("❌ Connection error:", e)
        sys.exit(1)


# ----------------------- #
#    HELPER FUNCTIONS     #
# ----------------------- #

def send_command(arduino, cmd):
    """Send control command to Arduino."""
    try:
        arduino.write((cmd + "\n").encode())
        print(f"> Sent to Arduino: {cmd}")
    except Exception as e:
        print(f"⚠️ Failed to send '{cmd}':", e)


def read_arduino_response(arduino):
    """Read and print responses from Arduino."""
    try:
        while arduino.in_waiting > 0:
            msg = arduino.readline().decode(errors='ignore').strip()
            if msg:
                print("Arduino:", msg)
    except Exception:
        pass


def read_weight_from_s99(s99):
    """
    Read one line from S-99 RS232 output,
    extract numeric value,
    detect unit (g/kg),
    return weight in grams.
    """
    try:
        line = s99.readline().decode(errors='ignore').strip()
        if line:
            match = re.search(r"([-+]?\d*\.\d+|\d+)", line)
            if match:
                weight = float(match.group(0))
                if "kg" in line.lower():
                    weight *= 1000
                return weight
    except Exception:
        pass
    return None


# ----------------------- #
#    MAIN CONTROL LOOP    #
# ----------------------- #

def main():
    s99, arduino = setup_serial_connections()
    conveyor_running = False

    print("✅ System Active — Monitoring weight from S-99...\n")

    try:
        while True:
            weight = read_weight_from_s99(s99)
            if weight is not None:
                print(f"Detected Weight: {weight:.1f} g")

                # ---- STOP & PICK ----
                if weight >= WEIGHT_THRESHOLD and conveyor_running:
                    send_command(arduino, "STOP")
                    read_arduino_response(arduino)
                    time.sleep(1)

                    send_command(arduino, "PICK")
                    read_arduino_response(arduino)

                    conveyor_running = False

                # ---- RESET & RUN ----
                elif weight <= 1 and not conveyor_running:
                    send_command(arduino, "RESET")
                    read_arduino_response(arduino)
                    time.sleep(1)

                    send_command(arduino, "RUN")
                    read_arduino_response(arduino)

                    conveyor_running = True

            time.sleep(0.2)

    except KeyboardInterrupt:
        print("\n🛑 Manual stop detected. Halting system.")
        send_command(arduino, "STOP")
    finally:
        s99.close()
        arduino.close()
        print("✅ Serial connections closed. Exiting...")


if __name__ == "__main__":
    main()
