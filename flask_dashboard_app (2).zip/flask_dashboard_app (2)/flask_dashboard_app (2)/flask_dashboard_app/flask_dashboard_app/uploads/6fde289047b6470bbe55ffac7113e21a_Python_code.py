import serial
import time
import re

# ----------------------- #
#      CONFIGURATION      #
# ----------------------- #

S99_PORT = "COM9"
ARDUINO_PORT = "COM11"
BAUD_RATE_S99 = 9600
BAUD_RATE_ARDUINO = 9600
WEIGHT_THRESHOLD = 500.0


# ----------------------- #
#   SERIAL CONNECTIONS    #
# ----------------------- #

try:
    s99_serial = serial.Serial(S99_PORT, BAUD_RATE_S99, timeout=1)
    arduino_serial = serial.Serial(ARDUINO_PORT, BAUD_RATE_ARDUINO, timeout=1)
    time.sleep(2)

    print(f"Connected to S-99 on {S99_PORT}")
    print(f"Connected to Arduino on {ARDUINO_PORT}\n")

except Exception as e:
    print("Connection error:", e)
    exit()


# ----------------------- #
#    HELPER FUNCTIONS     #
# ----------------------- #

def send_command(cmd):
    arduino_serial.write((cmd + "\n").encode())
    print(f"> Sent to Arduino: {cmd}")


def read_arduino_response():
    while arduino_serial.in_waiting > 0:
        msg = arduino_serial.readline().decode(errors='ignore').strip()
        if msg:
            print("Arduino:", msg)


def read_weight_from_s99():
    """
    Reads weight from scale and returns grams.
    """
    try:
        line = s99_serial.readline().decode(errors='ignore').strip()
        if line:
            match = re.search(r"([-+]?\d*\.\d+|\d+)", line)
            if match:
                weight = float(match.group(0))

                if "kg" in line.lower():
                    weight *= 1000

                return weight
    except:
        pass

    return None


# ----------------------- #
#    MAIN CONTROL LOOP    #
# ----------------------- #

try:
    print("System Active — Monitoring weight...\n")

    conveyor_running = False

    while True:
        weight = read_weight_from_s99()

        if weight is not None:
            print(f"Detected Weight: {weight:.1f} g")

            # STOP + PICK when threshold reached
            if weight >= WEIGHT_THRESHOLD and conveyor_running:
                send_command("STOP")
                read_arduino_response()
                time.sleep(1)

                send_command("PICK")
                read_arduino_response()
                conveyor_running = False

            # RESET + RUN when weight cleared
            elif weight <= 1 and not conveyor_running:
                send_command("RESET")
                read_arduino_response()
                time.sleep(1)

                send_command("RUN")
                read_arduino_response()
                conveyor_running = True

        time.sleep(0.2)

except KeyboardInterrupt:
    print("\nStopped by user.")
    send_command("STOP")
    s99_serial.close()
    arduino_serial.close()
