<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit Supplier
        </div>
        <div class="form-container">
            <?php
     $servername = "localhost";
     $username = "cybersur_new";
     $password = "2fXj!ii8z0aZ";
     $dbname = "cybersur_new";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if supplierId is set and is a number
                if (isset($_GET["supplierId"]) && is_numeric($_GET["supplierId"])) {
                    $supplierId = $_GET["supplierId"];

                    // Fetch supplier details from the database
                    $sql = "SELECT * FROM supplier WHERE supplier_id = $supplierId";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="supplier_id" value="<?php echo $supplierId; ?>">
                <div class="form-group">
                    <label for="supplier_name" class="form-label">Supplier Name:</label>
                    <input type="text" class="form-control" id="supplier_name" name="supplier_name" value="<?php echo $row['supplier_name']; ?>">
                </div>
                <div class="form-group">
                    <label for="Item_id" class="form-label">Item ID:</label>
                    <input type="text" class="form-control" id="Item_id" name="Item_id" value="<?php echo $row['Item_id']; ?>">
                </div>
                <div class="form-group">
                    <label for="contact" class="form-label">Contact:</label>
                    <input type="text" class="form-control" id="contact" name="contact" value="<?php echo $row['contact']; ?>">
                </div>
                <div class="form-group">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $row['email']; ?>">
                </div>
                <div class="form-group">
                    <label for="address" class="form-label">Address:</label>
                    <input type="text" class="form-control" id="address" name="address" value="<?php echo $row['address']; ?>">
                </div>
                <div class="button-container">
                <button type="submit" class="button-23">Update</button>
                </div>

                </form>


                        <?php
                    } else {
                        echo "Supplier not found";
                    }
                } else {
                    echo "Invalid supplierId";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the supplier
                // Retrieve updated supplier details from the form
                $supplierId = $_POST["supplier_id"];
                $supplier_name = $_POST["supplier_name"];
                $Item_id = $_POST["Item_id"];
                $contact = $_POST["contact"];
                $email = $_POST["email"];
                $address = $_POST["address"];

                // Update the supplier in the database
                $sql = "UPDATE supplier SET supplier_name='$supplier_name', Item_id='$Item_id', contact='$contact', email='$email', address='$address' WHERE supplier_id='$supplierId'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>Supplier updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='supplierview.php' class='button-23'>Go to Supplier View</a></div>";
                } else {
                    echo "Error updating supplier: " . $conn->error;
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
