<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Measurement Unit</title>
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa; /* Updated background color */
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .container {
            width: 400px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        
        .heading {
            font-size: 24px;
            color: #000000;
            margin-bottom: 20px;
            text-align: center;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        
        .button-container {
            text-align: center;
        }
        
        .button-23 {
            background-color: #0b0b0b; /* Updated button color */
            border: none;
            border-radius: 8px;
            color: #ffffff; /* White text color */
            font-size: 16px;
            font-weight: bold;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-block;
        }
        
        .button-23:hover {
            background-color: #333333; /* Darker color on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading">
            Edit Measurement Unit
        </div>
        <div class="form-container">
            <?php
              $servername = "localhost";
              $username = "cybersur_new";
              $password = "2fXj!ii8z0aZ";
              $dbname = "cybersur_new";
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($_SERVER["REQUEST_METHOD"] == "GET") {
                // Check if unitId is set and is a number
                if (isset($_GET["unitId"]) && is_numeric($_GET["unitId"])) {
                    $unit_id = $_GET["unitId"];

                    // Fetch unit details from the database
                    $sql = "SELECT * FROM measurement_unit WHERE unit_id = $unit_id";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="unit_id" value="<?php echo $unit_id; ?>">
                <div class="form-group">
                    <label for="unit_name" class="form-label">Unit Name:</label>
                    <input type="text" class="form-control" id="unit_name" name="unit_name" value="<?php echo $row['unit_name']; ?>">
                </div>
                <div class="form-group">
                    <label for="item_id" class="form-label">Item ID:</label>
                    <input type="text" class="form-control" id="item_id" name="item_id" value="<?php echo $row['Item_id']; ?>">
                </div>
                <div class="button-container">
                    <button type="submit" class="button-23">Update</button>
                </div>
            </form>
                        <?php
                    } else {
                        echo "Measurement Unit not found";
                    }
                } else {
                    echo "Invalid unitId";
                }
            } elseif ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Handle form submission to update the unit
                // Retrieve updated unit details from the form
                $unit_id = $_POST["unit_id"];
                $unit_name = $_POST["unit_name"];
                $item_id = $_POST["item_id"];

                // Update the unit in the database
                $sql = "UPDATE measurement_unit SET unit_name='$unit_name', Item_id='$item_id' WHERE unit_id='$unit_id'";

                if ($conn->query($sql) === TRUE) {
                    echo "<div style='text-align: center;'>Measurement Unit updated successfully. </div><br>";
                    echo "<div class='button-container'><a href='measurementview.php' class='button-23'>Go to Measurement Unit View</a></div>";
                } else {
                    echo "Error updating measurement unit: " . $conn->error;
                }
            }

            $conn->close();
            ?>
        </div>
    </div>
</body>
</html>
