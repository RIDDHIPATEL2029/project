"""
AI-Generated Automatic Feedback System

This application integrates an AI-assisted feedback generation system for grading student submissions. Instead of requiring instructors to manually write comments for each submission, the system uses AI-generated feedback templates that are dynamically selected based on the marks awarded.

How It Works:
- The system uses a set of professional feedback messages, crafted with the help of AI, for different mark ranges:
    - Excellent performance (80–100)
    - Good performance (65–79)
    - Satisfactory performance (50–64)
    - Below average (30–49)
    - Unsatisfactory (0–29)
- When an instructor enters a mark, the application automatically selects and applies the appropriate feedback message.
- The feedback is clear, motivational, professional, and consistent across all evaluations.

Benefits:
- Saves instructor time by automating feedback.
- Ensures consistent and fair grading for all students.
- Provides students with constructive, actionable comments.
- Adds professionalism and clarity to the grading process.

Example (see get_professional_feedback):
    def get_professional_feedback(marks):
        if marks >= 80:
            return "Excellent work! Your submission demonstrates a strong understanding of the material and attention to detail. Keep up the outstanding effort."
        elif marks >= 65:
            return "Good job! You have a solid grasp of the concepts, though there is some room for improvement. Review the feedback for further growth."
        elif marks >= 50:
            return "Satisfactory performance. You met the basic requirements, but there are areas that need more focus."
        elif marks >= 30:
            return "Below expectations. Some key concepts are missing or incomplete. Please revisit the material and seek clarification where needed."
        else:
            return "Unsatisfactory. The submission lacks essential elements. Please consult your instructor for guidance."

In summary, AI was used to design and generate the dynamic feedback messages provided during grading. This feature enhances the user experience by delivering personalized and academically styled feedback without requiring manual input from instructors.
"""
"""
AI-Assisted Unique File Naming Using UUID

One of the challenges in building a document submission portal is ensuring that multiple files with the same name do not overwrite each other when stored on the server. Students often upload files with common names such as:

    "Assignment.pdf"
    "Report.pdf"
    "Final.pdf"

If the application saved files using their original names, the system could easily overwrite a previous file, corrupt data, or mix submissions between students.

To solve this, AI assisted in designing and implementing a UUID-based unique file naming mechanism.

What the AI Helped Create:
AI suggested using UUIDs (Universally Unique Identifiers) to automatically generate unique prefixes for each uploaded file. This prevents filename collisions and guarantees that every uploaded file has a unique, traceable identity inside the system.

Example snippet:
    unique_prefix = uuid.uuid4().hex
    stored_filename = f"{unique_prefix}_{orig_filename}"

This creates filenames like:
    a4d3f9123bb24910bf333cd91d5ddf3c_Assignment.pdf
    8bdf322ab99242bdb8abe77d59efc2ad_Report.pdf

Why AI Suggested This Approach:
- Using UUID4, because it generates a statistically unique 128-bit value
- Using hex format to keep the filename short and filesystem-friendly
- Appending the original filename so instructors can still recognise the document

How It Solves Real Problems:
1. Prevents Overwriting: UUIDs ensure that files with the same name never overwrite each other.
2. Improves File Organisation: Keeps a clean separation between human-readable names (for display) and machine-safe names (for storage).
3. Enables Traceability: The UUID prefix helps track who uploaded the file and when.
4. Prevents Security Vulnerabilities: Secure filenames with UUIDs avoid issues with special characters or malicious filenames.

How You Can Write This in Your Report:
"AI assisted in designing the upload mechanism by recommending the use of UUID4-based unique filenames to prevent file overwriting and maintain a secure file storage system. The AI-generated pattern attaches a randomly generated hexadecimal identifier to every uploaded file, ensuring that each submission remains distinct even if students upload files with identical names. This approach improves safety, prevents accidental data loss, and maintains clean organisation between display names and storage names."

What Makes This a Good AI-Generated Feature?
- It is intelligent: solves a real backend problem
- It is safe: prevents file conflicts
- It improves user experience: students and teachers never see confusing filenames
- It is realistic: AI often suggests UUID logic in real development tasks
"""
import os
import fitz  # PyMuPDF
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_migrate import Migrate
from models import db, Student, Instructor, Submission
from sqlalchemy import inspect, text
import uuid

# ---------------- CONFIG -----------------
app = Flask(__name__)
app.secret_key = "supersecretkey"

# Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dashboard.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Upload folder
UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Initialize DB
db.init_app(app)
migrate = Migrate(app, db)

# ---------------- HELPER -----------------

def extract_text_from_pdf(pdf_path):
    try:
        text = ""
        with fitz.open(pdf_path) as doc:
            for page in doc:
                text += page.get_text("text")
        return text.strip()
    except Exception as e:
        print(f"PDF extract error: {e}")
        return ""

# ---------------- ROUTES -----------------
@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        role = request.form.get("role")
        name = request.form.get("name")
        email = request.form.get("email").lower()
        password = request.form.get("password")

        user = Student.query.filter_by(email=email).first() if role == "student" else Instructor.query.filter_by(email=email).first()

        # LOGIN
        if user:
            if check_password_hash(user.password_hash, password):
                session["user_id"] = user.id
                session["role"] = role
                flash(f"Welcome back, {user.name}!", "success")
                return redirect(url_for(f"{role}_dashboard"))
            else:
                flash("Incorrect password!", "danger")
                return redirect(url_for("home"))

        # REGISTER
        hashed_pw = generate_password_hash(password)
        if role == "student":
            new_user = Student(name=name, email=email, password_hash=hashed_pw)
        else:
            new_user = Instructor(name=name, email=email, password_hash=hashed_pw)

        db.session.add(new_user)
        db.session.commit()
        session["user_id"] = new_user.id
        session["role"] = role
        flash(f"{role.capitalize()} {new_user.name} registered successfully!", "success")
        return redirect(url_for(f"{role}_dashboard"))

    return render_template("home.html")

@app.route("/student/dashboard")
def student_dashboard():
    if "user_id" not in session or session.get("role") != "student":
        flash("Please login as student", "warning")
        return redirect(url_for("home"))

    student = Student.query.get(session["user_id"])
    submissions = Submission.query.filter_by(student_id=student.id).order_by(Submission.created_at.desc()).all()
    return render_template("student_dashboard.html", student=student, submissions=submissions)

@app.route("/student/upload", methods=["POST"])
def student_upload():
    if "user_id" not in session or session.get("role") != "student":
        flash("Please login as student", "warning")
        return redirect(url_for("home"))

    file = request.files.get("file")
    if not file:
        flash("No file selected", "danger")
        return redirect(url_for("student_dashboard"))

    orig_filename = secure_filename(file.filename)
    unique_prefix = uuid.uuid4().hex
    stored_filename = f"{unique_prefix}_{orig_filename}"
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], stored_filename)
    file.save(filepath)


    # --- Auto-grading for Python code files ---
    marks = None
    feedback = "Awaiting grading"
    passed = None
    if orig_filename.lower().endswith('.py'):
        try:
            import sys
            import importlib.util
            import subprocess
            import_path = os.path.join(os.getcwd(), 'test_cases.py')
            if os.path.exists(import_path):
                # Run the test_cases.py runner on the uploaded file
                result = subprocess.run([
                    sys.executable, import_path, filepath
                ], capture_output=True, text=True, timeout=10)
                output = result.stdout
                # Parse output for marks and feedback
                # (We will update test_cases.py to print a summary line)
                lines = output.strip().split('\n')
                summary = lines[-1] if lines else ''
                if summary.startswith('MARKS:'):
                    try:
                        marks = int(summary.split(':')[1].strip())
                        passed = marks >= 50
                        feedback = '\n'.join(lines[:-1])
                    except Exception:
                        feedback = output
                else:
                    feedback = output
            else:
                feedback = 'No test cases found for auto-grading.'
        except Exception as e:
            feedback = f'Auto-grading error: {e}'

    submission = Submission(
        title=orig_filename,
        stored_filename=stored_filename,
        student_id=session["user_id"],
        passed=passed,
        feedback=feedback,
        marks=marks
    )
    db.session.add(submission)
    db.session.commit()

    flash("File uploaded successfully!" + (" Auto-graded." if marks is not None else " Awaiting grading."), "success")
    return redirect(url_for("student_dashboard"))

    orig_filename = secure_filename(file.filename)
    # create unique stored filename to avoid collisions
    unique_prefix = uuid.uuid4().hex
    stored_filename = f"{unique_prefix}_{orig_filename}"
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], stored_filename)
    file.save(filepath)

    # Extract text for feedback (kept for future use)
    content = extract_text_from_pdf(filepath)

    # Save submission; store original display title and stored filename
    submission = Submission(
        title=orig_filename,
        stored_filename=stored_filename,
        student_id=session["user_id"],
        passed=None,
        feedback="Awaiting grading",
        marks=None
    )
    db.session.add(submission)
    db.session.commit()

    flash("File uploaded successfully! Awaiting grading.", "success")
    return redirect(url_for("student_dashboard"))

# ---------------- INSTRUCTOR DASHBOARD -----------------
@app.route("/instructor/dashboard")
def instructor_dashboard():
    if "user_id" not in session or session.get("role") != "instructor":
        flash("Please login as instructor", "warning")
        return redirect(url_for("home"))

    submissions = Submission.query.order_by(Submission.created_at.desc()).all()
    return render_template("instructor_dashboard.html", submissions=submissions)


@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    # Only allow logged-in users to access uploads
    if "user_id" not in session:
        flash("Please login to view files", "warning")
        return redirect(url_for("home"))
    try:
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
    except Exception as e:
        print(f"Error serving file: {e}")
        flash("File not found", "danger")
        return redirect(url_for("home"))


@app.route('/instructor/review/<int:sub_id>', methods=['GET', 'POST'])
def review_submission(sub_id):
    if "user_id" not in session or session.get("role") != "instructor":
        flash("Please login as instructor", "warning")
        return redirect(url_for("home"))

    submission = Submission.query.get_or_404(sub_id)

    if request.method == 'POST':
        # allow instructor to set marks and feedback
        try:
            marks_raw = request.form.get('marks')
            marks = int(marks_raw) if marks_raw not in (None, '') else None
        except ValueError:
            flash('Marks must be a number', 'danger')
            return redirect(url_for('review_submission', sub_id=sub_id))

        feedback = request.form.get('feedback')

        submission.marks = marks
        submission.passed = (marks >= 50) if marks is not None else None
        submission.feedback = feedback or submission.feedback
        db.session.commit()

        flash('Submission updated', 'success')
        return redirect(url_for('instructor_dashboard'))

    file_url = url_for('uploaded_file', filename=submission.title)
    return render_template('instructor_review.html', submission=submission, file_url=file_url)

@app.route("/grade/<int:sub_id>", methods=["POST"])
def grade_submission(sub_id):
    if "user_id" not in session or session.get("role") != "instructor":
        flash("Access denied", "danger") 
        return redirect(url_for("home"))

    submission = Submission.query.get_or_404(sub_id)
    marks = int(request.form.get("marks"))
    feedback = request.form.get("feedback")

    # Professional feedback based on marks
    def get_professional_feedback(marks):
        if marks >= 80:
            return "Excellent work! Your submission demonstrates a strong understanding of the material and attention to detail. Keep up the outstanding effort."
        elif marks >= 65:
            return "Good job! You have a solid grasp of the concepts, though there is some room for improvement. Review the feedback for further growth."
        elif marks >= 50:
            return "Satisfactory performance. You met the basic requirements, but there are areas that need more focus. Please review the comments and aim higher next time."
        elif marks >= 30:
            return "Below expectations. Some key concepts are missing or incomplete. Please revisit the material and seek clarification where needed."
        else:
            return "Unsatisfactory. The submission lacks essential elements and does not meet the minimum criteria. Please consult your instructor for guidance."

    submission.marks = marks
    submission.passed = marks >= 50
    submission.feedback = feedback or get_professional_feedback(marks)
    db.session.commit()

    flash(f"Submission graded: {submission.title}", "info")
    return redirect(url_for("instructor_dashboard"))

# ---------------- LOGOUT -----------------
@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out successfully", "info")
    return redirect(url_for("home"))

# ---------------- ERROR HANDLING -----------------
@app.errorhandler(500)
def internal_error(e):
    return render_template("error.html", message="Internal Server Error"), 500

@app.errorhandler(404)
def not_found(e):
    return render_template("error.html", message="Page Not Found"), 404

# ---------------- RUN APP -----------------
if __name__ == "__main__":
    with app.app_context():
        db.create_all()

        # Ensure `created_at` column exists on `submission` table to avoid runtime errors
        try:
            inspector = inspect(db.engine)
            cols = [c['name'] for c in inspector.get_columns('submission')] if 'submission' in inspector.get_table_names() else []
            # add created_at if missing
            if 'created_at' not in cols:
                try:
                    db.session.execute(text("ALTER TABLE submission ADD COLUMN created_at DATETIME"))
                    db.session.commit()
                    print("Added 'created_at' column to 'submission' table")
                except Exception as e:
                    print(f"Failed to add 'created_at' column: {e}")

            # add stored_filename if missing
            if 'stored_filename' not in cols:
                try:
                    db.session.execute(text("ALTER TABLE submission ADD COLUMN stored_filename VARCHAR(300)"))
                    db.session.commit()
                    print("Added 'stored_filename' column to 'submission' table")
                except Exception as e:
                    print(f"Failed to add 'stored_filename' column: {e}")
        except Exception as e:
            print(f"Could not inspect database schema: {e}")
    app.run(debug=True)
