from app import app, db
from models import Student, Instructor
from werkzeug.security import generate_password_hash

with app.app_context():
    # ----- Register a student -----
    student_name = "Test Student"
    student_email = "student@example.com"
    student_password = "password123"

    if Student.query.filter_by(email=student_email).first():
        print(f"Student {student_email} already exists.")
    else:
        student = Student(
            name=student_name,
            email=student_email,
            password_hash=generate_password_hash(student_password)
        )
        db.session.add(student)
        print(f"Student {student_name} registered successfully.")

    # ----- Register an instructor -----
    instructor_name = "Test Instructor"
    instructor_email = "instructor@example.com"
    instructor_password = "password123"

    if Instructor.query.filter_by(email=instructor_email).first():
        print(f"Instructor {instructor_email} already exists.")
    else:
        instructor = Instructor(
            name=instructor_name,
            email=instructor_email,
            password_hash=generate_password_hash(instructor_password)
        )
        db.session.add(instructor)
        print(f"Instructor {instructor_name} registered successfully.")

    # Commit all changes
    db.session.commit()
    print("All users registered successfully.")
