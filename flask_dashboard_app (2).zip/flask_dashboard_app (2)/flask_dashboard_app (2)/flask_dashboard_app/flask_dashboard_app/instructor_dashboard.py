@app.route("/teacher/submissions")
def teacher_submissions():
    if "user_id" not in session or session.get("role") != "instructor":
        flash("Please login as instructor", "warning")
        return redirect(url_for("home"))

    submissions = Submission.query.order_by(Submission.created_at.desc()).all()
    return render_template("instructor_dashboard.html", submissions=submissions)
