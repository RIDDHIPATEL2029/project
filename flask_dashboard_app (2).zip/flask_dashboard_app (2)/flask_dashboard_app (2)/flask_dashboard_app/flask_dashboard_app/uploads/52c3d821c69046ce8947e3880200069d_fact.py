inputs = input().split()
for num_str in inputs:
    try:
        num = int(num_str)
        fact = 1
        for i in range(1, num + 1):
            fact *= i
        print(fact)
    except:
        print("Enter a number:")