import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def evaluate_assignment(content):
    """Send student content to AI and return marks, feedback, pass/fail."""

    prompt = f"""
You are a university examiner. Evaluate the following student answer.

STUDENT SUBMISSION:
-------------------
{content}

RETURN THE RESULT STRICTLY IN JSON FORMAT:
{{
  "marks": <0-100>,
  "pass_fail": "Pass" or "Fail",
  "feedback": "Detailed feedback here"
}}
"""

    response = client.chat.completions.create(
        model="gpt-4.1",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    ai_output = response.choices[0].message.content

    # --------------------------
    # Convert AI JSON to Python
    # --------------------------
    import json
    try:
        result = json.loads(ai_output)
        return result
    except json.JSONDecodeError:
        # fallback if AI returns non-perfect JSON
        return {
            "marks": 0,
            "pass_fail": "Fail",
            "feedback": "AI returned invalid JSON. Please re-check submission."
        }
