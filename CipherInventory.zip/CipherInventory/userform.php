<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Prepare and bind parameters
    $stmt = $conn->prepare("INSERT INTO user (user_id, username, password, email, role) VALUES (?, ?, ?, ?, ?)");
    
    // Set parameters
    $userid = $_POST['user_id'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    $stmt->bind_param("sssss", $userid, $username, $password, $email, $role);

    
    // Execute the query
    if ($stmt->execute() === TRUE) {
        echo "<center>New record created successfully</center>";
    } else {
        echo "Error: " . $stmt->error;
    }
    
    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    <title>User</title>
    <style>
        html,body {
            font-family: 'DM Sans', sans-serif;
            user-select: none;
        }
        span{
            color: red;
            font-size: small;
            padding-left: 15px;
        }
        button{
            background-color: #0b0b0b;
        }
        ul{
            list-style-type: none;
        }
        li{
            padding: 0px 20px 0px 20px;
        }
        a{
            color: white;
        }
        .vr{
            color: white;
        }
        .drawer-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #0b0b0b;
            transition: left 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            padding-top: 50px;
            font-family: 'DM Sans', sans-serif;
        }

        .drawer-content {
            padding: 20px;
            color: white;
        }

        .drawer-toggle {
            position: fixed;
            top: 50%;
            left: -40px;
            transform: translateY(-50%);
            background-color: #0b0b0b;
            color: white;
            border: none;
            cursor: pointer;
            z-index: 1001;
            padding: 10px;
            border-radius: 0 10px 10px 0;
            transition: left 0.3s ease;
        }

        .drawer-toggle:hover {
            left: 0;
            background-color: #1a1a1a;
        }

        .drawer-link {
            display: block;
            padding: 10px;
            color: white;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .drawer-link:hover {
            background-color: #1a1a1a;
        }

        .main-form {
            padding-left: 50px;
        }
        .center-content {
            display: flex;
            justify-content: center; /* Center horizontally */
        }
        
    </style>
</head>
<body>
    <div class="drawer-container">
        <div class="drawer-content">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="controlpanel.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="orderform.php">Order</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="customerorderform.php">Customer Order</a>
                </li>
                
            </ul>
        </div>
    </div>
    <div class="container-fluid">
        <div class="center-content">
            <div>
                <div class="row p-5">
                    <div class="col-auto fw-bold" style="font-size: larger;">User Login</div>
                </div>
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <div class="row pt-3">
                    <div class="col-2"><label>User Id</label></div>
                    <div class="col-auto"><input class="mandatory" type="text" id="user_id" name="user_id"><span></span></div>
                </div>
                <div class="row pt-3">
                    <div class="col-2"><label>Username</label></div>
                    <div class="col-auto"><input class="mandatory" type="text" id="username" name="username"><span></span></div>
                </div>
                <div class="row pt-3">
                    <div class="col-2"><label>Password</label></div>
                    <div class="col-auto"><input class="mandatory" type="password" id="password"  name="password"><span></span></div>
                </div>
                <div class="row pt-3">
                    <div class="col-2"><label>Email</label></div>
                    <div class="col-auto"><input class="mandatory" type="email" name="email" pattern="/^([a-z0-9_\-\.])+\@([a-z_\-\.])+\.([a-z]{2,4})$/" id="email"><span id="emailSpan"></span></div>
                </div>
                <div class="row pt-3">
                    <div class="col-2"><label>Role</label></div>
                    <div class="col-auto"><input class="mandatory" type="text" id="role" name="role"><span></span></div>
                </div>
               
                <div class="row pt-3">
                    <div class="col-auto">
                        <button type="submit" class=" border border-white py-1 px-3 rounded-3 text-white " id="submitBtn" onclick="submitForm()" style="background-color: #0b0b0b">Submit</button>
                    </div>
                </div>
    </form>
    <form method="post" action="userview.php">
    <div class="col-auto">
                        <button type="submit" class=" border border-white py-1 px-3 rounded-3 text-white " id="submitBtn"  style="background-color: #0b0b0b">View User</button>
                    </div>
    </form>
            </div>
        </div>
    </div>

    <button class="drawer-toggle" id="drawer-toggle" onclick="toggleDrawer()">
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="180" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
          <path d="M5.854 3.646a.5.5 0 0 1 .708 0L11 8.293l-4.854 4.853a.5.5 0 1 1-.708-.708L9.293 8 5.146 3.854a.5.5 0 0 1 0-.708z"/>
          <path d="M10.854 3.646a.5.5 0 0 1 .708 0L16 8.293l-4.146 4.147a.5.5 0 1 1-.708-.708L15.293 8 11.146 3.854a.5.5 0 0 1 0-.708z"/>
        </svg>
    </button>

    <script>
    mandatory = document.getElementsByClassName("mandatory");
    email = document.getElementById("email");
    emailPtrn = /^([a-z0-9_\-\.])+\@([a-z_\-\.])+\.([a-z]{2,4})$/;
    filled = true;
    function submitForm(){
        filled = true;
        for (i = 0; i < mandatory.length; i++){
            if (mandatory[i].value == ""){
                filled = false;
                mandatory[i].nextSibling.innerHTML ="* "+ mandatory[i].name + " can't be empty *";
            } else {
                mandatory[i].nextSibling.innerHTML = "";
                if (email.value.match(emailPtrn)){
                    email.nextSibling.innerHTML = "";
                }else {
                    email.nextSibling.innerHTML = "* Invalid Email *";
                    filled = false;
                }
            }
        }
        if (filled == true){
          // alert("hello");
            
        } else {
            return false;
        }
    }
        function toggleDrawer() {
            var drawer = document.querySelector('.drawer-container');
            drawer.style.left = drawer.style.left === '0px' ? '-250px' : '0px';
        }
    </script>
</body>
</html>
