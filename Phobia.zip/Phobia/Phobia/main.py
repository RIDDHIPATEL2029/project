import os, json, datetime, webbrowser
from pathlib import Path
from tkinter import messagebox
from PIL import Image, ImageDraw, ImageFilter
import matplotlib.pyplot as plt
import customtkinter as ctk

# Paths
BASE_DIR = Path(__file__).resolve().parent
PHOBIAS_FILE = BASE_DIR / "phobias.json"
USER_FILE = BASE_DIR / "user_data.json"
IMAGES_DIR = BASE_DIR / "phobia_images"

# Load data
with open(PHOBIAS_FILE, "r") as f:
    phobias = json.load(f)

if USER_FILE.exists():
    with open(USER_FILE, "r") as f:
        user_data = json.load(f)
else:
    user_data = {"sessions": []}

def save_user_data():
    with open(USER_FILE, "w") as f:
        json.dump(user_data, f, indent=4)

# CustomTkinter setup
ctk.set_appearance_mode("Light")
ctk.set_default_color_theme("blue")

# Main app window
app = ctk.CTk()
app.title("Phobia Tracker — Responsive")
SCREEN_W = app.winfo_screenwidth()
SCREEN_H = app.winfo_screenheight()
APP_WIDTH = int(SCREEN_W * 0.8)
APP_HEIGHT = int(SCREEN_H * 0.8)
app.geometry(f"{APP_WIDTH}x{APP_HEIGHT}+{int(SCREEN_W*0.1)}+{int(SCREEN_H*0.1)}")
app.minsize(900, 600)

# Fonts
FONT_HEADER = ctk.CTkFont(family="Segoe UI", size=22, weight="bold")
FONT_SUB = ctk.CTkFont(family="Segoe UI", size=14, weight="bold")
FONT_TEXT = ctk.CTkFont(family="Segoe UI", size=12)

# Background gradient
bg_image_path = BASE_DIR / "bg_gradient.png"
if not bg_image_path.exists():
    w, h = 1920, 1080
    img = Image.new("RGB", (w, h), "#ff7896")
    draw = ImageDraw.Draw(img)
    for i in range(h):
        r = int(255 - (140 * i / h))
        g = int(120 - (40 * i / h))
        b = int(150 + (50 * i / h))
        draw.line([(0, i), (w, i)], fill=(r, g, b))
    img.save(bg_image_path)

bg_ctk = ctk.CTkImage(light_image=Image.open(bg_image_path), size=(APP_WIDTH, APP_HEIGHT))
bg_label = ctk.CTkLabel(app, image=bg_ctk, text="")
bg_label.place(relx=0, rely=0, relwidth=1, relheight=1)

# Frosted glass effect
def frosted_panel(width, height):
    panel = Image.open(bg_image_path).resize((width, height)).filter(ImageFilter.GaussianBlur(15))
    overlay = Image.new("RGBA", (width, height), (255, 255, 255, 80))
    panel = Image.alpha_composite(panel.convert("RGBA"), overlay)
    return ctk.CTkImage(light_image=panel, size=(width, height))

# Drop shadow
def create_shadow_img(width, height, radius=12, blur=8):
    shadow = Image.new("RGBA", (width + blur*2, height + blur*2), (0, 0, 0, 0))
    draw = ImageDraw.Draw(shadow)
    draw.rounded_rectangle((blur, blur, width+blur, height+blur), radius=radius, fill=(0,0,0,80))
    return ctk.CTkImage(light_image=shadow.filter(ImageFilter.GaussianBlur(blur)), size=(width+blur*2, height+blur*2))

# Dynamic image loader
def load_image(name):
    # Static image size (you can adjust if needed)
    img_size = (550, 500)  

    img_path = IMAGES_DIR / (name.replace(" ", "_") + ".png")
    if img_path.exists():
        img = Image.open(img_path).convert("RGB")
        img = img.resize(img_size, Image.LANCZOS)  # Force resize to fixed size
    else:
        img = Image.new("RGB", img_size, color=(180, 180, 200))  # Placeholder

    return ctk.CTkImage(light_image=img, size=img_size)


# Layout frames
sidebar = ctk.CTkFrame(app, corner_radius=20, fg_color="#ffffff", border_color="#dddddd", border_width=1)
sidebar.place(relx=0.02, rely=0.05, relwidth=0.20, relheight=0.9)

content = ctk.CTkFrame(app, corner_radius=20, fg_color="#ffffff", border_color="#dddddd", border_width=1)
content.place(relx=0.24, rely=0.07, relwidth=0.74, relheight=0.86)

# Sidebar buttons
logo = ctk.CTkLabel(sidebar, text="PhobiaGram", font=FONT_HEADER, text_color="black")
logo.pack(pady=(20,10))

btn_phobias = ctk.CTkButton(sidebar, text="📜 Phobia List", corner_radius=12, fg_color="#c084fc", hover_color="#a855f7", text_color="white", command=lambda: show_page("phobias"))
btn_progress = ctk.CTkButton(sidebar, text="📊 Progress", corner_radius=12, fg_color="#f472b6", hover_color="#ec4899", text_color="white", command=lambda: show_page("progress"))
btn_settings = ctk.CTkButton(sidebar, text="⚙️ Settings", corner_radius=12, fg_color="#38bdf8", hover_color="#0ea5e9", text_color="white", command=lambda: show_page("settings"))
btn_phobias.pack(pady=8, padx=16, fill="x")
btn_progress.pack(pady=8, padx=16, fill="x")
btn_settings.pack(pady=8, padx=16, fill="x")

ctk.CTkLabel(sidebar, text="Built with ❤️", font=ctk.CTkFont(size=11), text_color="black").pack(side="bottom", pady=12)

# Helpers
def clear_content():
    for w in content.winfo_children():
        w.destroy()

# Pages
def page_phobias():
    clear_content()
    header = ctk.CTkLabel(content, text="Phobia Explorer", font=FONT_HEADER, text_color="black")
    header.pack(pady=(12, 6))

    scroll_frame = ctk.CTkScrollableFrame(content, corner_radius=12, fg_color="#ffffff")
    scroll_frame.pack(expand=True, fill="both", padx=12, pady=12)

    def show_phobia(name):
        clear_content()
        # Back button
        back_btn = ctk.CTkButton(content, text="⬅ Back", command=page_phobias, 
                                 corner_radius=12, fg_color="#94a3b8", hover_color="#64748b", text_color="white")
        back_btn.pack(pady=(8,4), padx=12, anchor="w")

        details = phobias[name]

        # Image
        img_label = ctk.CTkLabel(content, image=load_image(name), text="")
        img_label.pack(pady=12)

        # Name
        ctk.CTkLabel(content, text=name, font=FONT_HEADER, text_color="black").pack(pady=(6, 4))

        # Description and symptoms
        txt = f"{details.get('description', '')}\n\nSymptoms: {details.get('symptoms', '')}"
        ctk.CTkLabel(content, text=txt, justify="left", wraplength=int(APP_WIDTH*0.6), text_color="black").pack(padx=12, pady=(4, 12))

    # Create one button per phobia
    for name in phobias.keys():
        btn = ctk.CTkButton(scroll_frame, text=name, corner_radius=12, 
                            fg_color="#c084fc", hover_color="#a855f7", text_color="white",
                            command=lambda n=name: show_phobia(n))
        btn.pack(pady=6, padx=16, fill="x")

def page_progress():
    clear_content()
    header = ctk.CTkLabel(content, text="Progress Tracker", font=FONT_HEADER, text_color="black")
    header.pack(pady=(12,6))

    frame = ctk.CTkFrame(content, corner_radius=12, fg_color="#ffffff")
    frame.pack(padx=16, pady=12, fill="both", expand=True)

    left = ctk.CTkFrame(frame, corner_radius=12, fg_color="#ffffff")
    right = ctk.CTkFrame(frame, corner_radius=12, fg_color="#ffffff")

    left.place(relx=0.02, rely=0.03, relwidth=0.48, relheight=0.94)
    right.place(relx=0.52, rely=0.03, relwidth=0.46, relheight=0.94)

    ctk.CTkLabel(left, text="Rate Today's Anxiety", font=FONT_SUB, text_color="black").pack(pady=(20,6))
    slider = ctk.CTkSlider(left, from_=1, to=10, number_of_steps=9)
    slider.set(5)
    slider.pack(pady=8, padx=20, fill="x")

    ctk.CTkLabel(left, text="Notes", font=FONT_SUB, text_color="black").pack(pady=(12,6))
    notes = ctk.CTkTextbox(left, font=FONT_TEXT)
    notes.pack(padx=20, pady=6, fill="both", expand=True)

    def save_session():
        rating = int(round(slider.get()))
        note = notes.get("1.0", "end").strip()
        today = str(datetime.date.today())
        user_data.setdefault("sessions", []).append({"date": today, "rating": rating, "note": note})
        save_user_data()
        messagebox.showinfo("Saved", "Session saved successfully.")

    save_btn = ctk.CTkButton(left, text="Save Session", command=save_session, corner_radius=12, fg_color="#22c55e", hover_color="#16a34a", text_color="white")
    save_btn.pack(pady=12, padx=20, fill="x")

    ctk.CTkLabel(right, text="Recent Sessions", font=FONT_SUB, text_color="black").pack(pady=(18,6))
    sessions_frame = ctk.CTkScrollableFrame(right, corner_radius=12, fg_color="#ffffff")
    sessions_frame.pack(padx=12, pady=6, fill="both", expand=True)

    for s in user_data.get("sessions", [])[-12:][::-1]:
        t = f"{s.get('date','?')} — Rating: {s.get('rating', '?')}"
        item = ctk.CTkLabel(sessions_frame, text=t, anchor="w", text_color="black")
        item.pack(fill="x", padx=8, pady=4)

    def show_graph():
        sessions = user_data.get("sessions", [])
        if not sessions:
            messagebox.showinfo("No Data", "No sessions to plot.")
            return
        dates = [s["date"] for s in sessions]
        ratings = [s["rating"] for s in sessions]
        plt.figure(figsize=(8,4))
        plt.plot(dates, ratings, marker='o', linestyle='-')
        plt.title("Anxiety Rating Over Time")
        plt.xlabel("Date")
        plt.ylabel("Rating (1-10)")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()

    graph_btn = ctk.CTkButton(right, text="Show Progress Graph", command=show_graph, corner_radius=12, fg_color="#3b82f6", hover_color="#2563eb", text_color="white")
    graph_btn.pack(padx=12, pady=8, fill="x")

def page_settings():
    clear_content()
    header = ctk.CTkLabel(content, text="Settings", font=FONT_HEADER, text_color="black")
    header.pack(pady=(12,6))
    ctk.CTkLabel(content, text="Open phobias.json or user_data.json to edit data manually.", wraplength=int(APP_WIDTH*0.5), text_color="black").pack(padx=12, pady=6)
    def open_folder():
        webbrowser.open(str(BASE_DIR))
    ctk.CTkButton(content, text="Open Project Folder", command=open_folder, fg_color="#3b82f6", hover_color="#2563eb", text_color="white").pack(pady=12)

def show_page(name):
    if name == "phobias":
        page_phobias()
    elif name == "progress":
        page_progress()
    elif name == "settings":
        page_settings()

# Update UI when window resizes
def on_resize(event):
    global APP_WIDTH, APP_HEIGHT
    APP_WIDTH, APP_HEIGHT = event.width, event.height

app.bind("<Configure>", on_resize)

# Start
show_page("phobias")
app.mainloop()
