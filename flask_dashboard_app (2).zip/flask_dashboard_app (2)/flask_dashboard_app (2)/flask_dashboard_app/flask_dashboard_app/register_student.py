from app import app, db
from models import Student
from werkzeug.security import generate_password_hash

# Wrap in app context
with app.app_context():
    # Replace with your desired student info
    name = "Test Student"
    email = "student@example.com"
    password = "password123"

    # Check if email already exists
    if Student.query.filter_by(email=email).first():
        print("Student with this email already exists.")
    else:
        # Hash the password
        hashed_password = generate_password_hash(password)

        # Create student record
        student = Student(name=name, email=email, password_hash=hashed_password)
        db.session.add(student)
        db.session.commit()
        print(f"Student {name} registered successfully with email {email}.")
