<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    <title>Customer Order Form</title>
    <style>
        html,body {
            font-family: 'DM Sans', sans-serif;
            background-color: #f8f9fa;
            color: #0b0b0b;
            overflow-x:hidden;
            margin: 0;
            padding: 0;
        }
        .drawer-container {
            position: fixed;
            top: 0;
            left: -250px;
            width: 250px;
            height: 100%;
            background-color: #0b0b0b;
            transition: left 0.3s ease;
            z-index: 1000;
            overflow-y: auto;
            padding-top: 50px;
            font-family: 'DM Sans', sans-serif;
            color: #f8f9fa;
        }

        .drawer-content {
            padding: 20px;
        }

        .drawer-toggle {
            position: fixed;
            top: 50%;
            left: -40px;
            transform: translateY(-50%);
            background-color: #0b0b0b;
            color: #f8f9fa;
            border: none;
            cursor: pointer;
            z-index: 1001;
            padding: 10px;
            border-radius: 0 10px 10px 0;
            transition: left 0.3s ease;
        }

        .drawer-toggle:hover {
            left: 0;
            background-color: #0b0b0b;
        }

        .drawer-link {
            display: block;
            padding: 10px;
            color: #f8f9fa;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }

        .drawer-link:hover {
            background-color: #1a1a1a;
        }

        .main-form {
            padding-left: 20px;
            margin-top: 20px;
        }

        .main-form label {
            font-weight: bold;
            margin-right: 10px;
        }

        .main-form select {
            padding: 8px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-bottom: 10px;
            width: 200px;
        }

        .main-form input[type="submit"] {
            padding: 10px 20px;
            background-color: #0b0b0b;
            color: #f8f9fa;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .table-container {
            margin-top: 20px;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #f8f9fa;
            color: #0b0b0b;
            border: 1px solid #000; /* Added border */
        }

        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #000;
            font-weight: bold; /* Bold border */
        }

        th {
            background-color: #0b0b0b;
            color: #f8f9fa;
        }

        tr:nth-child(even) {
            background-color: #e9ecef;
        }
    </style>
</head>
<body>
    <div class="drawer-container">
        <div class="drawer-content">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="controladmin.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminuserform.php">User Form</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminorderform.php">Order</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="customerorderform.php">Customer Order</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminitemcategory.php">Item Category</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminitemform.php">Item</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminmeasurementform.php">Measurement Unit</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link drawer-link" href="adminsupplierform.php">Supplier</a>
                </li>
            </ul>
        </div>
    </div>
    <button class="drawer-toggle" id="drawer-toggle" onclick="toggleDrawer()">
        <svg xmlns="http://www.w3.org/2000/svg" width="30" height="180" fill="currentColor" class="bi bi-chevron-double-right" viewBox="0 0 16 16">
          <path d="M5.854 3.646a.5.5 0 0 1 .708 0L11 8.293l-4.854 4.853a.5.5 0 1 1-.708-.708L9.293 8 5.146 3.854a.5.5 0 0 1 0-.708z"/>
          <path d="M10.854 3.646a.5.5 0 0 1 .708 0L16 8.293l-4.146 4.147a.5.5 0 1 1-.708-.708L15.293 8 11.146 3.854a.5.5 0 0 1 0-.708z"/>
        </svg>
    </button>
    <div class="main-form">
        <h2>Order Form</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="order_id">Order ID:</label>
            <select name="order_id" id="order_id">
                <option value="all">View All</option> <!-- View All option added -->
                <?php
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";
                
                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT order_id FROM customer_order";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['order_id'] . "'>" . $row['order_id'] . "</option>";
                    }
                } else {
                    echo "<option value=''>No Orders</option>";
                }
                $conn->close();
                ?>
            </select>
            <br><br>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>

    <div class="table-container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $selected_order_id = $_POST['order_id'];

            echo "<div class='main-form'>";
            echo "<h2>Customer Order</h2>";
            echo "<table border='1'>";
            echo "<tr><th>Order ID</th><th>User ID</th><th>Item ID</th><th>Order Date</th><th>Quantity</th><th>Total Price</th><th>Is QR Scanned</th><th>QR Code</th></tr>";

            $servername = "localhost";
            $username = "cybersur_new";
            $password = "2fXj!ii8z0aZ";
            $dbname = "cybersur_new";
            
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            if ($selected_order_id == 'all') {
                $sql = "SELECT * FROM customer_order";
            } else {
                $sql = "SELECT * FROM customer_order WHERE order_id = $selected_order_id";
            }
            
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $item_id = $row["Item_id"];
                    $sql_item = "SELECT qrcode FROM customer_order WHERE Item_id = $item_id";
                    $res_item = $conn->query($sql_item);
                    $rowqr = $res_item->fetch_assoc();
                    $qrpath = $rowqr["qrcode"];

                    echo "<tr><td>" . $row['order_id'] . "</td><td>" . $row['user_id'] . "</td><td>" . $item_id . "</td><td>" . $row['order_date'] . "</td><td>" . $row['quantity'] . "</td><td>" . $row['total_price'] . "</td><td>" . $row['isqrscanned'] . "</td><td><img src='".$qrpath."' width='100' height='100'/></td></tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No orders found for selected ID</td></tr>";
            }

            echo "</table>";
            echo "</div>";
            $conn->close();
        }
        ?>
    </div>

    <button onclick="generatePDF()">Generate PDF</button>

<script>
    function generatePDF() {
        var doc = new jsPDF();

        // Get table element
        var table = document.querySelector('table');

        // Convert table to PDF
        doc.autoTable({ html: table });

        // Save the PDF
        doc.save('customer_order.pdf');
    }
    function toggleDrawer() {
    var drawer = document.querySelector('.drawer-container');
    drawer.style.left = drawer.style.left === '0px' ? '-250px' : '0px';
}

</script>

    </script>
</body>
</html>
