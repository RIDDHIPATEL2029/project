<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    <title>Login</title>
    <style>
        html,body {
            font-family: 'DM Sans', sans-serif;
            user-select: none;
            background-color: #0b0b0b;
            overflow-x: hidden;
            height: 100%;
            margin: 0;
            padding: 0;
            position: relative;
            overflow-x: hidden;
        }
        span{
            color: red;
            font-size: small;
            padding-left: 15px;
        }
        button{
            background-color: #0b0b0b;
        }
        .welcome-text {
            text-align: center;
            margin-top: 15%;
            font-size: 3.3rem;
            color: #333;
        }
        .login-box {
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease-in-out;
        }
        .login-box:hover {
            box-shadow: 0 0 20px rgba(0,0,0,0.3);
        }
        .container-fluid {
            perspective: 1px;
            height: 100vh;
            overflow-x: hidden;
            overflow-y: auto;
        }
        .decor {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1;
        }
        @keyframes animate {
            0% {
                transform: scale(1) translate(0, 0) rotate(0deg);
            }
            100% {
                transform: scale(1.5) translate(-50%, -50%) rotate(360deg);
            }
        }
        
    </style>
</head>
<body>
    <div class="row justify-content-center align-items-center" style="height: 100vh;">
        <div class="col-md-4">
            <div class="login-box">
                <div class="row pt-3">
                    <div class="col-auto fw-bold h1">Login</div>
                </div>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"> <!-- Form submission to the same page -->
                    <div class="row pt-3">
                        <div class="col-12"><label>User ID :</label></div>
                        <div class="col-12"><input class="mandatory form-control" type="text" id="username" name="username"></div>
                        <span class="col-12"></span>
                    </div>
                    <div class="row pt-3">
                        <div class="col-12"><label>Password</label></div>
                        <div class="col-12"><input class="mandatory form-control" type="password" id="password" name="password"></div>
                        <span class="col-12"></span>
                    </div>
                    
                    <div class="row pt-3 justify-content-center">
                        <div class="col-auto">
                            <button type="submit" class="border border-white py-1 px-3 rounded-3 text-white" id="submitBtn">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $role = $row['role'];
        
        switch ($role) {
            case 'user':
                header("Location: controlpanel.php");
                break;
            case 'admin':
                header("Location: controladmin.php");
                break;
            case 'stockmanager':
                header("Location: controlstock.php");
                break;
            default:
                echo "Invalid role";
        }
    } else {
        echo "Invalid username or password";
    }

    $conn->close();
}
?>
</body>
<script>
    mandatory = $(".mandatory");
    $("#submitBtn").click(function(){
        filled = true;
        mandatory.each(function(){
            if ($(this).val() == ""){
                filled = false;
                $(this).parent().next().html("* " + $(this).attr("name") + " can't be empty *");
            } else {
                $(this).parent().next().html("");
            }
        });
        if ( filled == true){
            var role = $("#roleSelect").val();
            if (role == "admin") {
                window.location.href = "admin_panel.html";
            } else if (role == "user") {
                window.location.href = "user_panel.html";
            } else if (role == "stock_manager") {
                window.location.href = "stock_manager_panel.html";
            }
        } else {
            return false;
        }
    })
</script>
</html>
