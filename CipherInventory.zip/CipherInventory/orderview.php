<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order View</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://unpkg.com/gridjs/dist/theme/mermaid.min.css" rel="stylesheet" />
    <style>
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #0b0b0b;
            margin: 0;
            padding: 0;
        }

        .container {
            margin-top: 20px;
        }

        .heading {
            font-size: 30px;
            color: #ffffff;
        }

        .button-container {
            margin-top: 20px;
        }

        /* Button Styling */
        .button-23 {
            background-color: #f0f0f0; /* Light gray background color */
            border: 1px solid #222222;
            border-radius: 8px;
            color: #222222; /* Dark text color */
            font-size: 16px;
            font-weight: 600;
            line-height: 20px;
            padding: 13px 23px;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .button-23:hover {
            background-color: #e0e0e0; /* Lighter gray on hover */
        }

        /* Table Styling */
        .gridjs-container {
            border-radius: 8px;
            overflow: hidden;
        }

        .gridjs {
            border-collapse: collapse;
            width: 100%;
        }

        .gridjs th,
        .gridjs td {
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
            color: #0b0b0b;
        }

        .gridjs th {
            background-color: #f0f0f0; /* Light gray background color */
            font-weight: 600;
            text-align: left;
        }

        .gridjs tbody tr:nth-child(even) {
            background-color: #333333;
        }

        .gridjs tbody tr:hover {
            background-color: #444444;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 py-5">
                <div class="row">
                    <div class="col-auto fw-medium heading">
                        Orders
                    </div>
                </div>
                <div class="row mt-3">
                    <div id="wrapper"></div>
                </div>
                <div class="row mt-3 button-container">
                    <div class="col-auto">
                        <a href="orderform.php" class="button-23" role="button">Add Order </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://unpkg.com/gridjs/dist/gridjs.umd.js"></script>
    <script>
        let data = [
            <?php
    $servername = "localhost";
    $username = "cybersur_new";
    $password = "2fXj!ii8z0aZ";
    $dbname = "cybersur_new";
            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT * FROM customer_order";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '[' . $row["order_id"] . ', ' . $row["user_id"] . ', "' . $row["order_date"] . '",' . $row["total_price"] . '],';
                }
            }
            $conn->close();
            ?>
        ];

        let grid = new gridjs.Grid({
            columns: [
                { name: "Order ID", id: "order_id" },
                { name: "User ID", id: "user_id" },
                { name: "Order Date", id: "order_date" },
                { name: "Total Price", id: "total_price" },
                {
                    name: "Actions",
                    formatter: (_, row) => gridjs.html(`<button onclick="editUser(${row.cells[0].data})" class="btn btn-primary btn-sm">Edit</button>
                                                          <button onclick="deleteUser(${row.cells[0].data})" class="btn btn-danger btn-sm">Delete</button>`)
                }
            ],
            search: true,
            sort: true,
            resizable: true,
            pagination: true,
            data: data,
        }).render(document.getElementById("wrapper"));

        function editUser(orderId) {
            window.location.href = 'editorder.php?orderId=' + orderId;
        }

        function deleteUser(orderId) {
            if (confirm("Are you sure you want to delete this order?")) {
            window.location.href = 'deleteorder.php?orderId=' + orderId;

            }
        }
    </script>
</body>

</html>
